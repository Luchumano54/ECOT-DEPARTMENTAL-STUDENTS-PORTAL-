<!DOCTYPE html>
<html>

<head>
<?php
include('functionality.php');
$object = new alpha();

?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <a name="rp">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">180239003 </a>
                <button class="navbar-toggle collapsed"  data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a href="Student Profile.php"> Student Profile</a></li>
                    <li role="presentation"><a href="#">Assessments </a></li>
                   <!-- <li role="presentation"><button href="FAS HOF1.php"> Reports</button></li>  -->
                    <li role="presentation"><a href="NOT CM STU final.php" class="custom-navbar"> Notifications<span class="badge">10 </span></a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            <li role="presentation"><a href="#">Settings </a></li>
                            <li role="presentation"><a href="#">Payments </a></li>
                            <li role="presentation" class="active"><a href="LOGINPAGE.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Reports </h1>
    <hr>
    <div class="container">
        <div>
            <ul class="nav nav-tabs">
                <li><a href="#tab-1" role="tab" data-toggle="tab">Continuous Asseements</a></li>
                <li class="active"><a href="#tab-2" role="tab" data-toggle="tab">Final Mark</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane" role="tabpanel" id="tab-1"></div>
                <div class="tab-pane" role="tabpanel" id="tab-3">
                    <p>Third tab content.</p>
                </div>
            </div>
        </div>
        <hr>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div></div>
            </div>
            <div class="col-md-4 col-md-offset-0">
                <h3 class="text-right"> ECOT FINAL REPORT</h3></div>

            <div class="card" class="container">
        <div class="card-header">
            <div class="row">
                <div class="col col-sm-2 ">
                 <img class="img-responsive" src="assets/img/ECZOT.jpg" width="100px">   
                </div>
                <div class="col col-sm-2 text-right">
                    <a href="<?php echo $object->base_url; ?>" class="btn btn-warning btn-sm">Back</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php
            
            $download_button = '';
            if(isset($_POST["submit"]))
            {
                $data = array(
                    ':student_roll_no'      =>  trim($_POST["student_roll_no"])
                );
                $object->query = "
                SELECT * FROM student_srms 
                WHERE student_roll_no = :student_roll_no 
                AND student_status = 'Enable' 
                ";

                $class_id = '';
                $student_id = '';
                $result_id = '';

                $object->execute($data);

                if($object->row_count() > 0)
                {
                    foreach($object->statement_result() as $student_data)
                    {
                        echo '
                        <p><b>Roll No. - </b>'.trim($_POST["student_roll_no"]).'</p>
                        <p><b>Student Name - </b>'.html_entity_decode($student_data["student_name"]).'</p>
                        <p><b>Email ID - </b>'.$student_data["student_email_id"].'</p>
                        <div class="row">
                            <div class="col-md-6">
                                <p><b>Date of Birth - </b>'.$student_data["student_dob"].'</p>
                            </div>
                            <div class="col-md-6">
                                <p><b>Gender - </b>'.$student_data["student_gender"].'</p>
                            </div>
                        </div>                      
                        <p><b>Class Name - </b>'.$object->Get_class_name($student_data["class_id"]).'</p>';

                        $class_id = $student_data["class_id"];
                        $student_id = $student_data["student_id"];
                    }

                    $object->query = "
                    SELECT * FROM exam_srms 
                    WHERE exam_id = '".$_POST["exam_name"]."'
                    ";
                    $exam_result = $object->get_result();

                    foreach($exam_result as $exam_data)
                    {
                        echo '
                        <div class="row">
                            <div class="col-md-6">
                                <p><b>Exam - </b>'.$exam_data["exam_name"].'</p>
                            </div>
                            <div class="col-md-6">
                                <p><b>Date & Time - </b>'.date("Y-m-d H:i:s").'</p>
                            </div>
                        </div>
                        ';
                    }

                    $object->query = "
                    SELECT * FROM result_srms 
                    WHERE class_id = '$class_id' 
                    AND student_id = '$student_id' 
                    AND exam_id = '".$_POST['exam_name']."'
                    ";

                    $result_data = $object->get_result();
                    foreach($result_data as $result)
                    {
                        if($result["result_status"] == "Enable")
                        {
                            $result_id = $result["result_id"];

                            echo '
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <tr>
                                        <th>#</th>
                                        <th>Subject</th>
                                        <th>Obtain Mark</th>
                                    </tr>
                            ';
                            $object->query = "
                            SELECT subject_srms.subject_name, marks_srms.marks 
                            FROM marks_srms 
                            INNER JOIN subject_srms 
                            ON subject_srms.subject_id = marks_srms.subject_id 
                            WHERE marks_srms.result_id = '".$result["result_id"]."'
                            ";
                            $marks_data = $object->get_result();
                            $count = 0;
                            $total = 0;
                            foreach($marks_data as $marks)
                            {
                                $count++;
                                echo '
                                    <tr>
                                        <td>'.$count.'</td>
                                        <td>'.$marks["subject_name"].'</td>
                                        <td>'.$marks["marks"].'</td>
                                    </tr>
                                ';
                                $total += $marks["marks"];
                            }
                            echo '
                                    <tr>
                                        <td colspan="2" align="right"><b>Total</b></td>
                                        <td>'.$total.'</td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" align="right"><b>Percentage</b></td>
                                        <td>'.$result["result_percentage"].'%</td>
                                    </tr>
                                </table>
                            </div>
                            ';
                            $download_button = '<a href="download.php?exam_id='.$_POST['exam_name'].
                            '&student_roll_no='.$_POST["student_roll_no"]. '" class="btn btn-danger"><i class="fas fa-file-pdf-o" aria-hidden="true"></i> Download Result</a>';
                        }
                        else
                        {
                            echo '<h4 align="center">Your Result has put on hold contact Admin of Exam Section</h4>';
                        }
                    }
                }
                else
                {
                    echo '<h4 align="center">No Result Found</h4>';
                }
            }
            else
            {
                echo '<h4 align="center">No Result Found</h4>';
            }

            ?>
            
        </div>
        <div class="card-footer text-center">
            <?php echo $download_button; ?>
        </div>
    </div>
    <br />
            <br />
            <br />  </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>