


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body>
    <div></div><img class="img-responsive" src="assets/img/FINALv2.jpg">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">180239003 </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                   <!-- <li role="presentation"><a class="text-muted bg-warning" href="#">Student Profile</a></li> -->
                    <li role="presentation"><a href="#">Assessments </a></li>
                    <li role="presentation"><a href="RP.php"> Reports</a></li>
                    <li role="presentation"><a href="#" class="custom-navbar"> Inbox<span class="badge">10 </span></a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown open">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            <li role="presentation" class="active"><a href="LOGINPAGE.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div></div>
    <hr>
    <h1 class="text-center">Student Profile </h1>
    <hr>
    <div class="container">
        <div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr></tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Student ID</td>
                            <td>180239003</td>
                        </tr>
                        <tr>
                            <td>Student Name</td>
                            <td>Zolile Mlotshwa</td>
                        </tr>
                        <tr></tr>
                        <tr>
                            <td>Year </td>
                            <td>3rd year</td>
                        </tr>
                        <tr>
                            <td>Program </td>
                            <td>Diploma In Computer Science</td>
                        </tr>
                        <tr>
                            <td>Courses Enrolled In :</td>
                            <td colspan="3"> </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="container">
        <ul>
            <li>Applied Mathematics - DCS 300</li>
            <li>Programming - DCS 301</li>
            <li>Software Engineering - DCS 302</li>
            <li>Networking II - DCS 303</li>
            <li>Router Funamentals - DCS 304</li>
            <li>Servers - DCS 305</li>
        </ul>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>