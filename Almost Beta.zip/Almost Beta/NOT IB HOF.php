<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">Ms Dlamini</a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a class="text-muted bg-warning" href="FAS HOF.php">Find A Student</a></li>
                      <li role="presentation"><a href="FAS.HOF.php"> Add A Student</a></li>
                     <li role="presentation"><a href="Reports HOF.php"> Reports</a></li>
                    <!--<li role="presentation"><a href="#" class="custom-navbar"> Notifications<span class="badge">10 </span></a></li> -->
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            <li role="presentation"><a href="#">Settings </a></li>
                            <li role="presentation"><a href="#">Payments </a></li>
                            <li role="presentation" class="active"><a href="LOGINPAGE.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Notifications </h1>
    <hr>
    <div class="container">
        <div>
            <ul class="nav nav-tabs">
                <li class="active"><a href="#tab-1" role="tab" data-toggle="tab">Inbox </a></li>
                <li><a href="#tab-2" role="tab" data-toggle="tab">Create Broadcast</a></li>
                <li><a href="#tab-3" role="tab" data-toggle="tab">Compose Message</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" role="tabpanel" id="tab-1"></div>
                <div class="tab-pane" role="tabpanel" id="tab-2"></div>
                <div class="tab-pane" role="tabpanel" id="tab-3"></div>
                <div class="tab-pane" role="tabpanel" id="tab-4">
                    <p>Tab content.</p>
                </div>
            </div>
        </div>
        <hr>
    </div>
    <div class="container">
        <div class="panel-group" role="tablist" aria-multiselectable="true" id="accordion-1">
            <div class="panel panel-default">
                <div class="panel-heading" role="tab">
                    <h4 class="panel-title"><a role="button" data-toggle="collapse" data-parent="#accordion-1" aria-expanded="true" href="#accordion-1 .item-1">Inbox From: Mr Dladla.</a></h4></div>
                <div class="panel-collapse collapse in item-1" role="tabpanel">
                    <div class="panel-body">
                        <div class="col-md-12 col-md-offset-0 col-md-push-0"><span> </span>
                            <p class="text-nowrap text-left">Dear Madam</p>
                            <p>I have uploaded test 2 marks in the portal for our Third years.</p>
                            <p>Mr Dladla[Lect004]</p>
                            <hr>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <textarea></textarea>
                            </div>
                            <div class="col-md-8 col-md-offset-1"></div>
                            <div class="col-md-12">
                                <button class="btn btn-default" type="button">Reply Message</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading" role="tab">
                    <h4 class="panel-title"><a role="button" data-toggle="collapse" data-parent="#accordion-1" aria-expanded="false" href="#accordion-1 .item-2">Inbox From: Mr Dlamini [LECT001] Departmental Meeting</a></h4></div>
                <div class="panel-collapse collapse item-2" role="tabpanel">
                    <div class="panel-body"><span>Item body.</span></div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading" role="tab">
                    <h4 class="panel-title"><a role="button" data-toggle="collapse" data-parent="#accordion-1" aria-expanded="false" href="#accordion-1 .item-3">Inbox From: Sinethemba Dlamini[180239004] Request for an appointment</a></h4></div>
                <div class="panel-collapse collapse item-3" role="tabpanel">
                    <div class="panel-body"><span>Item body.</span></div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>