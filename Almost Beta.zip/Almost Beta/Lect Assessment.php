<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">Mr Dlamini</a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a class="text-muted bg-warning" href="Find A Student lecturer.php">Find A Student</a></li>
                  <!---  <li role="presentation"><a href="#">Assessments </a></li>  -->
                    <li role="presentation"><a href="LECT Report.php"> Reports</a></li>
                    <li role="presentation"><a href="NOT IB LECT.php" class="custom-navbar"> Inbox<span class="badge">10 </span></a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            <li role="presentation"><a href="#">Settings </a></li>
                            <li role="presentation"><a href="#">Payments </a></li>
                            <li role="presentation" class="active"><a href="LOGINPAGE.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Assesments </h1>
    <hr>
    <div class="container">
        <div>
            <ul class="nav nav-tabs">
                <li class="active"><a href="#tab-1" role="tab" data-toggle="tab">Upload Work</a></li>
                <li><a href="#tab-2" role="tab" data-toggle="tab">Download Work </a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" role="tabpanel" id="tab-1">
                    <p>Remember to set due Date and Time.</p>
                </div>
                <div class="tab-pane" role="tabpanel" id="tab-2">
                    <p>Second tab content.</p>
                </div>
                <div class="tab-pane" role="tabpanel" id="tab-3">
                    <p>Third tab content.</p>
                </div>
            </div>
        </div>
        <hr>
    </div>
    <div class="container">
        <form class="bootstrap-form-with-validation">
            <div class="form-group">
                <label class="control-label" for="search-input">Upload Assignment</label>
                <div class="input-group">
                    <div class="input-group-addon"><span> <a href="#">Set Due Date Here!</a></span></div>
                    <input class="form-control" type="search" name="search-input" id="search-input">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label" for="file-input">File Input</label>
                <input type="file" name="file-input" id="file-input">
            </div>
            <div class="form-group"></div>
            <div class="form-group">
                <button class="btn btn-primary" type="submit">Upload </button>
            </div>
        </form>
        <hr>
        <form class="bootstrap-form-with-validation">
            <div class="form-group">
                <label class="control-label" for="search-input">Upload Test</label>
                <div class="input-group">
                    <div class="input-group-addon"><span> <a href="#">Set Due Time Here!</a></span></div>
                    <input class="form-control" type="search" name="search-input" id="search-input">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label" for="file-input">File Input</label>
                <input type="file" name="file-input" id="file-input">
            </div>
            <div class="form-group"></div>
            <div class="form-group">
                <button class="btn btn-primary" type="submit">Upload </button>
            </div>
        </form>
        <hr>
        <form class="bootstrap-form-with-validation">
            <div class="form-group">
                <label class="control-label" for="search-input">Upload Quiz</label>
                <div class="input-group">
                    <div class="input-group-addon"><span> <a href="#">Set Due Time Here!</a></span></div>
                    <input class="form-control" type="search" name="search-input" id="search-input">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label" for="file-input">File Input</label>
                <input type="file" name="file-input" id="file-input">
            </div>
            <div class="form-group"></div>
            <div class="form-group">
                <button class="btn btn-primary" type="submit">Upload </button>
            </div>
        </form>
        <hr>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>