<?php
     include 'Calendar.php';
    include 'connection.php';

    
?>





<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
    <link href="calendar.css" rel="stylesheet" type="text/css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg" style="width: 100%;">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">

            <?php

                session_start();
                 if (empty($_SESSION['user_id'])){
                    header("location: LOGINPAGE.php");
                    exit();
    }
            ?>

            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#"><?php echo $_SESSION['user_id']; ?> </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>

            </div>
            <?php  
         
                    $sql_get = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                    $count = mysqli_num_rows($sql_get);

            ?>

            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a class="text-muted bg-warning" href="find_student.php">Find A Student</a></li>
                    <li role="presentation"><a href="assess_lecturer.php">Assessments </a></li>
                    <li role="presentation"><a href="cal_lect.php">Add Event </a></li>
                    <li role="presentation"><a href="res.php"> Reports</a></li>
                    <li role="presentation"><a href="NOT CB LECT.php" class="custom-navbar">  Notification <span class="badge" ><?php echo $count; ?> </span></a></li>
                    <li><li class="dropdown open">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" href="#"> <span class="caret"></span></a>
                        <ul class="dropdown-menu dropdown-menu" role="menu">
                            <?php
                                    $sql_get1 = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                                    if(mysqli_num_rows($sql_get1)) 
                                    {
                                        while ($result =mysqli_fetch_assoc($sql_get1))
                                         {
                                           /* echo '<li role="presentation" class="active"  text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].'"> '.$result['message'].'  </a></li>'; -->  */
                                            echo '<a class="dropdown-item" text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].' ">'.$result['message']. '</a></li>';
                                           echo '<div class ="dropdown-divider"></div>';
                                        }
                                    }else
                                    {
                                        echo '<a class="dropdown-item" text="primary" class="active" text="danger" font="bold">Sorry no new messages </a></li>';
                                    }


                            ?>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                           
                            <li role="presentation" class="active"><a href="LOGINPAGE.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Calender</h1>
    <div class="container">
    <form action="<?php echo $_SERVER["PHP_SELF"] ?>" name="form" method="post">
<div class="form-group" method="post">

                <label class="control-label" for="date">Event Date</label>
            </div>
            <input class="form-control" type="date" name="event_date" id="event_date" required="">
            <div class="form-group"></div> 
            <table>
                <tr>
                    <col>
                    <div class="form-group">
                <label class="control-label" for="text-input">Event Name</label>
                <input class="form-control" type="text" name="event_name" id="event_name" required="">
            </div>
                </col>

                <col>
                <div class="form-group">
                <label class="control-label" for="text-input">Event Duration</label>
                <input class="form-control" type="number" name="event_days" id="event_days" required="">
            </div>
                </col>
                <col>
                <div class="form-group">
                <label class="control-label" for="text-input">Intesity</label>
                <input class="form-control" type="text" name="event_color" id="event_color" required="">
            </div>
                </col>
                <col>
                 <div class="form-group">
                 
                <button action ="$_POST" name="submit" id="submit" type="submit"  class="btn btn-primary">Done </button>
                </form>
                
            </div>
</col>
                </tr>



            </table>
<div class="container">
    <hr>
    
    <div class="container">

    <!-- <?=$calendar?>-->
    </div>
    <div class="container">
        <hr>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>


<?php


$conn = new mysqli("localhost", "root","","student portal");
$calendar = new Calendar('2021-02-02');


if (isset($_POST['submit'])) {
$date = $_POST['event_date'];
$txt = $_POST['event_name'];
$days = $_POST['event_days'];
$color = $_POST['event_color'];
$posts = array();

$calendar->add_event($_POST['event_name'],$_POST['event_date'] , $_POST['event_days'], $_POST['event_color']);

 //"INSERT INTO `student portal`.`event_table` ( `event_name`, `event_date`, `event_days`, `event_color`) VALUES ('exams', '2021-02-11', '4', 'red')";
$sql= "INSERT INTO event_table (event_date,event_name,event_days,event_color) VALUES ('$date','$txt','$days','$color')";
$result = $conn->query($sql);


    $sqli = mysqli_query($conn,"SELECT*FROM event_table");
    if(isset($_GET['event_table'])){

        foreach ($sqli as $event_id) {
            $calendar->add_event($_GET[$txt['event_name']], $_GET[$date['event_date']], $_GET[$days['event_days']], $_GET[$color['event_color']]);
        }
      }

 }
if ($conn->query($sql) === TRUE) {
 
  echo "<script>alert ('New record created successfully')</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();



 

?>
</html>