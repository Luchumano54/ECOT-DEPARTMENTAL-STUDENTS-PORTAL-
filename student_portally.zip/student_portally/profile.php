<!DOCTYPE html>


<html>
<head>
	

</head>
<body>


<?php

//if (isset($_GET['user_id'])) {
	//$user_id = $_GET['user_id'];
	//var_dump($user_id);
  //  $mysql = new mysqli ("localhost","root","") or die ("Could not connect to the server");
    //mysql_select_db("user") or die("That database could not be found");
    //$userquery = mysql_query("SELECT * FROM user WHERE user_id='$user_id'") or die("invalid query");
    
    //if($mysql->connect_error){
    //	die("Fatal problem".$mysql->connect_error);
    //}

if (isset($_GET['user_id'])) {
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
  $conn = new mysqli("localhost", "root","","Student portal");
  $sql = "SELECT * FROM `user` WHERE `user_id`=\"".$_GET["user_id"]."\"";
  $result = mysqli_query($conn,$sql);
  $row = mysqli_fetch_assoc($result);








    /*if($r = $mysql->query()){
   		while ($r = $r->fetch_assoc()) { 
    	
    	  	}
    	$r-> free();

    }
*/
   // $r = $mysql->query("SELECT * FROM user WHERE user_id = 'user_id'");
   // if(mysqli_num_rows($r) !==1){
    //	die ("That User ID is not found");
   // }
    //print_r($r);
   // echo "nor".$r->num_rows;

    var_dump($sql);
    while ($row = $sql->fetch_assoc()) {
    	
       $user_name		= $row('user_name');
       $dbuser_id 		= $row('user_id');
       $user_phone 		= $row('user_phone');
       $user_email 		= $row('user_email');
       $user_password 	= $row('user_password');
       $user_type 		= $row('user_type');
       $user_status		= $row('user_status');
    }
    if($user_id != $dbuser_id){
         die("error");
       }
    if($user_status == $disable){
    	$user_status ="Your profile has been disabled";
    }else{
    	$user_status ="Your Profile is anable";
    }if($user_type = 'Student'){

    	echo "sinethemba";
    }

  
?>
<h2> <?php echo $firstname; ?> Profile</h2><br/>
<table>
	<tr><td>Student ID:<td><td><?php echo $stu_num; ?></td></tr>
	<tr><td>Student Name:<td><td><?php echo $stu_name; ?></td></tr>
	<tr><td>Year:<td><td><?php echo $year_code; ?></td></tr>
	<tr><td>Student Gender:<td><td><?php echo $stu_gender ?></td></tr>
	<tr><td>Student Email Address:<td><td><?php echo $stu_email ?></td></tr>
	<tr><td>Student Date Of Birth:<td><td><?php echo $stu_dob?></td></tr>
</table>

}


<?php
}else die ("You need to specify a user ID!");

?>

</body>
</html>