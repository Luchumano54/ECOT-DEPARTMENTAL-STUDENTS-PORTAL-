<?PHP

$DCS100_status = 'unchecked';
$DCS200_status = 'unchecked';
$DCS300_status = 'unchecked';

if (isset($_POST['Submit2'])) {

$selected_radio = $_POST['course'];

if ($selected_radio = = 'DCS100') {

$DCS100_status = 'checked';

}
else if ($selected_radio = = 'DCS200') {

$DCS200_status = 'checked';

}

else if ($selected_radio = = 'DCS200') {

$DCS300_status = 'checked';

}
}

?>