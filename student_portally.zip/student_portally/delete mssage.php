<?php

include("connection.php");

if(isset($_GET['id']))
{
	$db_id =$_GET['id'];
	$sql_delete = mysqli_query($conn,"DELETE FROM send_message WHERE id ='$db_id'");
	if($sql_delete)
	{

		header('location: NOT CM STU final.php');
	}
	else
	{
		echo mysqli_error($conn);
	}
}


?>