-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2021 at 09:09 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `assessment`
--

CREATE TABLE `assessment` (
  `assessment_id` int(255) NOT NULL,
  `assessment_title` int(255) NOT NULL,
  `assessment_size` int(255) NOT NULL,
  `assessment_downloads` int(255) NOT NULL,
  `assessment_date` date NOT NULL,
  `course_code` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assessment`
--

INSERT INTO `assessment` (`assessment_id`, `assessment_title`, `assessment_size`, `assessment_downloads`, `assessment_date`, `course_code`) VALUES
(1, 0, 4, 6, '2021-06-02', ''),
(2, 0, 701955, 0, '2021-06-09', ''),
(3, 180239013, 342667, 0, '2021-06-24', 'DCS104'),
(4, 180239013, 513189, 0, '2021-06-15', 'DCS102'),
(5, 180239013, 513189, 0, '2021-06-15', 'DCS102'),
(6, 0, 424909, 0, '2021-06-16', 'DCS101'),
(7, 0, 701955, 0, '2021-06-09', 'DCS104'),
(8, 0, 408994, 0, '2021-06-02', 'DCS103'),
(9, 0, 300808, 0, '2021-07-25', 'DCS101');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_code` varchar(255) NOT NULL,
  `year_code` varchar(255) NOT NULL,
  `lecturer_id` int(255) NOT NULL,
  `course_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_code`, `year_code`, `lecturer_id`, `course_name`) VALUES
('DCS101', 'DCS100', 0, 'Computer Programming'),
('DCS102', 'DCS100', 0, 'Computer Architecture'),
('DCS103', 'DCS100', 0, 'Database Management'),
('DCS104', 'DCS100', 0, 'Mathematics'),
('DCS106', 'DCS100', 0, 'Science');

-- --------------------------------------------------------

--
-- Table structure for table `event_table`
--

CREATE TABLE `event_table` (
  `event_id` int(11) NOT NULL,
  `event_name` text NOT NULL,
  `event_date` date NOT NULL,
  `event_days` int(11) NOT NULL,
  `event_color` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_table`
--

INSERT INTO `event_table` (`event_id`, `event_name`, `event_date`, `event_days`, `event_color`) VALUES
(1, 'exams', '2021-02-11', 4, 'red'),
(2, 'exams', '2021-02-11', 4, 'red'),
(3, 'exams', '2021-02-11', 4, 'red'),
(4, 'exams', '2021-02-11', 4, 'red'),
(5, 'exams', '2021-02-11', 4, 'red'),
(6, 'exams', '2021-02-11', 4, 'red'),
(7, 'wew', '2021-02-05', 2, 'green'),
(8, 'wew', '2021-02-05', 2, 'green'),
(9, 'wew', '2021-02-05', 2, 'green'),
(10, 'wew', '2021-02-05', 2, 'green'),
(11, 'wew', '2021-02-05', 2, 'green'),
(12, 'wew', '2021-02-05', 2, 'green'),
(13, 'wew', '2021-02-05', 2, 'green'),
(14, 'wew', '2021-02-05', 2, 'green'),
(15, 'sandlies birth', '2021-06-09', 3, 'green'),
(16, 'sandlies birth', '2021-06-09', 3, 'green'),
(17, 'hjgkjh', '2021-06-18', 4, 'red'),
(18, 'hjgkjh', '2021-06-18', 4, 'red'),
(19, 'hjgkjh', '2021-06-18', 4, 'red'),
(20, 'hjgkjh', '2021-06-18', 4, 'red'),
(21, 'hjgkjh', '2021-06-18', 4, 'red'),
(22, 'hjgkjh', '2021-06-18', 4, 'red'),
(23, 'sandlies birth', '2021-02-11', 3, 'red'),
(24, 'sandlies birth', '2021-02-11', 3, 'red'),
(25, 'test', '2021-02-05', 1, 'red'),
(26, 'test', '2021-02-05', 1, 'red'),
(27, 'sandlies birth', '2021-02-11', 3, 'red'),
(28, 'sandlies birth', '2021-02-11', 3, 'red'),
(29, 'sandlies birth', '2021-06-04', 2, 'red'),
(30, 'sandlies birth', '2021-06-04', 2, 'red'),
(31, 'test', '2021-02-05', 6, 'green'),
(32, 'test', '2021-02-05', 6, 'green'),
(33, 'Exams Week', '2021-06-21', 4, 'red'),
(34, 'Exams Week', '2021-06-21', 4, 'red'),
(35, 'maths test', '2021-06-07', 1, 'red'),
(36, 'maths test', '2021-06-07', 1, 'red'),
(37, 'maths test', '2021-06-21', 3, 'red'),
(38, 'maths test', '2021-06-21', 3, 'red'),
(39, 'maths test', '2021-06-21', 3, 'red'),
(40, 'maths test', '2021-06-21', 3, 'red'),
(41, 'Exams Week', '2021-06-21', 4, 'red'),
(42, 'Exams Week', '2021-06-21', 4, 'red'),
(43, 'Test', '2021-07-24', 60, 'Hard'),
(44, 'Test', '2021-07-24', 60, 'Hard');

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `exam_id` int(255) NOT NULL,
  `year_code` varchar(255) NOT NULL,
  `exam_result_published` varchar(255) NOT NULL,
  `EXAM_RESULT_DATE` date NOT NULL,
  `EXAM_STATUS` enum('Enable','Disable') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`exam_id`, `year_code`, `exam_result_published`, `EXAM_RESULT_DATE`, `EXAM_STATUS`) VALUES
(10190025, 'DCS100', '', '2021-05-19', 'Enable'),
(10290025, 'DCS100', '', '2021-06-01', 'Enable'),
(10390025, 'DCS100', '', '2021-05-19', 'Enable'),
(10490025, 'DCS100', '', '2021-05-19', 'Enable'),
(10690025, 'DCS100', '', '2021-05-20', 'Enable');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `lecturer_id` int(255) NOT NULL,
  `title` text NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `MARKS_ID` int(255) NOT NULL,
  `RESULT_ID` int(255) NOT NULL,
  `C_CODE` varchar(255) NOT NULL,
  `MARKS` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`MARKS_ID`, `RESULT_ID`, `C_CODE`, `MARKS`) VALUES
(101111, 101100, 'DCS100', '90.00%'),
(102111, 102100, 'DCS100', '55.00%'),
(103111, 103100, 'DCS100', '61.00%'),
(104111, 104100, 'DCS100', '67.00%'),
(106111, 106100, 'DCS100', '70.00%');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(255) NOT NULL,
  `send_to` varchar(255) NOT NULL,
  `name` text NOT NULL,
  `message` text NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`id`, `send_to`, `name`, `message`, `status`, `date`) VALUES
(22, 'DCS 100', 'Class reps', 'WDFGN', 1, '2021-06-04 03:32:28'),
(23, 'DCS 100', 'Meeting', 'exams', 1, '2021-06-04 01:28:26'),
(24, 'All Student', 'Meeting', 'exams', 1, '2021-06-04 01:29:58'),
(25, 'DCS 100', 'Class reps', 'qwxgfvch', 1, '2021-06-04 01:32:03');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_table`
--

CREATE TABLE `quiz_table` (
  `student_id` int(255) NOT NULL,
  `course_code` varchar(255) NOT NULL,
  `quiz1` int(255) NOT NULL,
  `quiz2` int(255) NOT NULL,
  `quiz3` int(255) NOT NULL,
  `quiz4` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `quiz_table`
--

INSERT INTO `quiz_table` (`student_id`, `course_code`, `quiz1`, `quiz2`, `quiz3`, `quiz4`) VALUES
(180239002, 'DCS 101', 0, 0, 0, 0),
(180239002, 'DCS 102', 0, 0, 0, 0),
(180239002, 'DCS 103', 0, 0, 0, 0),
(180239002, 'DCS 104', 0, 0, 0, 0),
(180239002, 'DCS 105', 0, 0, 0, 0),
(180239002, 'DCS 106', 0, 0, 0, 0),
(180239002, 'DCS 107', 0, 0, 0, 0),
(180239002, 'DCS 108', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `RESULT_ID` int(255) NOT NULL,
  `YEAR_ID` varchar(255) NOT NULL,
  `STUDENT_ID` int(255) NOT NULL,
  `EXAM_ID` int(255) NOT NULL,
  `RESULT_PERCENTAGE` varchar(255) NOT NULL,
  `RESULT_STATUS` enum('Enable','Disable') NOT NULL,
  `RESULT ADDED BY` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`RESULT_ID`, `YEAR_ID`, `STUDENT_ID`, `EXAM_ID`, `RESULT_PERCENTAGE`, `RESULT_STATUS`, `RESULT ADDED BY`) VALUES
(101100, 'DCS100', 180239005, 10190025, '76.00%', 'Enable', 'Miss.P.D'),
(102100, 'Dcs100', 180239028, 10290025, '66.00%', 'Enable', 'Miss.P.D'),
(103100, 'DCS100', 180239022, 10390025, '80.00%', 'Enable', 'Miss.P.D'),
(104100, 'DCS100', 180239008, 10490025, '60.00%', 'Enable', 'Miss.P.D'),
(106100, 'DCS100', 180239012, 10690025, '72.00%', 'Enable', 'Miss.P.D');

-- --------------------------------------------------------

--
-- Table structure for table `result_sheet`
--

CREATE TABLE `result_sheet` (
  `Student_num` int(255) NOT NULL,
  `course_code` varchar(255) NOT NULL,
  `assignment` int(255) NOT NULL,
  `quiz` int(11) NOT NULL,
  `test` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result_sheet`
--

INSERT INTO `result_sheet` (`Student_num`, `course_code`, `assignment`, `quiz`, `test`) VALUES
(180239005, 'DCS101', 100, 0, 0),
(0, 'DCS101', 0, 100, 0),
(180239005, 'DCS101', 0, 0, 100),
(180239005, 'DCS101', 0, 68, 0);

-- --------------------------------------------------------

--
-- Table structure for table `send_message`
--

CREATE TABLE `send_message` (
  `id` int(255) NOT NULL,
  `send_to` varchar(255) NOT NULL,
  `tittle` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `status` int(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `send_message`
--

INSERT INTO `send_message` (`id`, `send_to`, `tittle`, `message`, `status`, `date`) VALUES
(6, '180239004', 'Need help', 'dscsccvfbtrd', 0, '0000-00-00'),
(7, '180239004', 'Need help', 'wer xcvb', 0, '0000-00-00'),
(8, '180239004', 'Need help', 'wer xcvb', 0, '0000-00-00'),
(9, '180239023', 'test', 'asdxcvbnm', 0, '2021-06-04'),
(10, '180239028', 'test', 'qwsdfvbn', 0, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `studentp`
--

CREATE TABLE `studentp` (
  `StudentNumber` varchar(255) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `PhoneNum` int(100) NOT NULL,
  `passwordd` varchar(255) NOT NULL,
  `Gender` text NOT NULL,
  `datee` date NOT NULL,
  `course` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentp`
--

INSERT INTO `studentp` (`StudentNumber`, `FirstName`, `LastName`, `PhoneNum`, `passwordd`, `Gender`, `datee`, `course`) VALUES
('180239005', 'Phumuza', 'Dlamini', 7668789, '76742211', 'm', '2021-05-08', ''),
('1802390166', 'ntsikaYEZWE', 'ndzinisa', 7668789, '76742211', 'm', '2021-05-08', ''),
('180239016667', 'ntsikaYEZWE', 'ndzinisa', 7668789, '76742211', 'm', '2021-05-08', ''),
('180239019', 'Lenie ', 'Msimango', 7802345, '12345', 'm', '2020-04-02', 'DCS100'),
('1892378', 'ntsika', 'dlamini', 1234567, '7875', 'f', '2021-05-01', 'dcs100'),
('189237866', 'sneroo', 'ndzinisa', 76742211, '675678', 'm', '2021-05-07', ''),
('18923786633', 'sneroo', 'ndzinisa', 76742211, '675678', 'm', '2021-05-07', '');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `test_id` int(255) NOT NULL,
  `test_name` text NOT NULL,
  `size` int(255) NOT NULL,
  `downloadd` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`test_id`, `test_name`, `size`, `downloadd`) VALUES
(1, 'h.txt', 1054, 0),
(2, 'h.txt', 1054, 0),
(3, 'h.txt', 1054, 0),
(4, 'cont.txt', 22, 0),
(5, 'h.txt', 1054, 0),
(6, '[eBook] Neale Donald Walsch - Conversations with God - volume 1.pdf', 701955, 0),
(7, '180239013 ntsikayezwe ntsinisa.pdf', 513189, 0),
(8, 'Academic C. S..pdf', 408994, 0),
(9, 'Visio UML 2.5 Tips.pdf', 415407, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_phone` int(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_type` enum('Lecturer','Student','HOF') NOT NULL,
  `user_status` enum('Enable','Disable') NOT NULL,
  `profile_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_phone`, `user_email`, `user_password`, `user_type`, `user_status`, `profile_image`) VALUES
('180239005', 'Phumuza.D', 79961468, 'dlaminiphumuza@gmail.com', '12345', 'Student', 'Enable', ''),
('180239008', 'Lutho.S', 78511989, 'simetlutho@gmail.co', '0000', 'Student', 'Enable', ''),
('180239012', 'Siyabonga.M', 76175650, 'mnciasiya@yahoo.com', 'siya1', 'Student', 'Enable', ''),
('Lect202101', 'Miss.P.D', 78407926, 'misslangeni@gmail.com', 'la222', 'HOF', 'Enable', ''),
('Lect202102', 'Mr.Malinga', 79836293, 'mrmalinga@yahoo.com', '24681', 'Lecturer', 'Enable', ''),
('Lect202103', 'Mr.S.D', 79504365, 'mrdlamini@gmail.com', 'mr240', 'Lecturer', 'Enable', '');

-- --------------------------------------------------------

--
-- Table structure for table `year_enrolled`
--

CREATE TABLE `year_enrolled` (
  `YEAR-CODE` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `YEAR_STATUS` enum('Enable','Disable') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `year_enrolled`
--

INSERT INTO `year_enrolled` (`YEAR-CODE`, `NAME`, `YEAR_STATUS`) VALUES
('DCS100', 'Lomasontfo.S', 'Enable'),
('DCS100', 'Lutho.S', 'Enable'),
('DCS100', 'Majaha.S', 'Enable'),
('DCS100', 'Siyabonga.M', 'Enable'),
('DCS100', 'Tandzile.D', 'Enable');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assessment`
--
ALTER TABLE `assessment`
  ADD PRIMARY KEY (`assessment_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_code`);

--
-- Indexes for table `event_table`
--
ALTER TABLE `event_table`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`lecturer_id`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`MARKS_ID`,`RESULT_ID`,`C_CODE`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`RESULT_ID`,`YEAR_ID`,`STUDENT_ID`,`EXAM_ID`);

--
-- Indexes for table `send_message`
--
ALTER TABLE `send_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`test_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`,`user_phone`,`user_email`);

--
-- Indexes for table `year_enrolled`
--
ALTER TABLE `year_enrolled`
  ADD PRIMARY KEY (`YEAR-CODE`,`NAME`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assessment`
--
ALTER TABLE `assessment`
  MODIFY `assessment_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `event_table`
--
ALTER TABLE `event_table`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
