<?php 
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
  session_start();

 /* $host = "localhost";
  $user_id = "root";
  $password = "";
  $dbname = "Student portal";
  */

if(isset($_POST['Log'])){

/*var_dump (isset($_POST['Log']));*/
$conn = new mysqli("localhost", "root","","Student portal");

//$sql = "SELECT `user_id`,`user_name` FROM `user` WHERE `user_id`=\"".$_POST["user_id"]."\" AND `user_password`=\"".$_POST["user_password"]."\"";
$sql = "SELECT `user_id`,`user_type` FROM `user` WHERE `user_id`=\"".$_POST["user_id"]."\" AND `user_password`=\"".$_POST["user_password"]."\"";


  $result = mysqli_query($conn,$sql); 

  $row = mysqli_fetch_assoc($result);

 // var_dump($row);
  //msg = "";
//$row = $row[0];
//var_dump($row);
 /* $conn = new mysqli("localhost", "root","","Student portal");

 
//try {
    //$conn = new PDO("mysql:host=localhost;dbname=Student portal", $user_id, $password);
     
    //$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if(isset($_POST['LOGIN'])){
      $user_id = $_POST['user_id'];
      $user_password = $_POST['user_password'];
      $user_password = sha1($user_password);
   //
    $user_type = $_POST['user_type'];

   $sql = "SELECT * FROM user WHERE user_id=? AND user_password=? AND user_type=?";
   $results = $conn->query($sql);

   var_dump($results->fetch_assoc());
 }

  $stmt =$conn->prepare($sql);
$stmt->close();
   $stmt->bind_param("sss",$user_id,$user_password,$user_type);
   $stmt->execute();
   $result = $stmt->get_result();
   $row = $sql->fetch_assoc();
*/
 //var_dump($row["user_type"]);
   session_regenerate_id();
   
  $_SESSION['user_id'] = $row["user_id"];
  //$_SESSION['user_name'] =$row["user_name"];
  $_SESSION['user_type'] = $row["user_type"];
 // session_write_close();
  

   if($result->num_rows==1 && $_SESSION['user_type']=="Student"){
    header("location: Student profile.php");
    //echo "student ";

   }
    else if($result->num_rows==1 && $_SESSION['user_type']=="Lecturer"){
    header("location:Lect Assessment.php");
      //echo "Lecturer ";
    } 
    else if($result->num_rows==1 && $_SESSION['user_type']=="H.O.F") {
    //header("location:hoof.php");
      echo "HOF";
    }
    else{
         $msg = "Username or Password is Incorrect!";
    }
 // } 
//    }
/*catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }*/
}
 ?>