<?php

    include("connection.php");

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body>
    <img class="img-responsive" src="assets/img/FINALv2.jpg" style="width: 100%;">
   <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
             <?php

                session_start();
                 if (empty($_SESSION['user_id'])){
                    header("location: index.php");
                    exit();
                }
            ?>
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">
                <?php echo $_SESSION['user_id']; ?> </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span><span class="icon-bar">
                    </span><span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a class="text-muted bg-warning" href="fasHOF.php">Find A Student</a></li>
                      <li role="presentation"><a href="add_student_final.php"> Add A Student</a></li>
                     <li role="presentation"><a href="reportsHOF.php"> Reports</a></li>
                     <li role="presentation"><a href="addevent.php">Add Event</a></li>
                    <li role="presentation"><a href="notificationHOF.php" class="custom-navbar"> Notification<span class="badge">10 </span></a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            <li role="presentation"><a href="#">Settings </a></li>
                            <li role="presentation" class="active"><a href="index.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Reports </h1>
    <hr>
    <div class="container">
        <div>
            <ul class="nav nav-tabs">
                <li class="active"><a href="#tab-1" role="tab" data-toggle="tab">Recommendations </a></li>
                <li><a href="#tab-2" role="tab" data-toggle="tab">Generate Report</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" role="tabpanel" id="tab-1">
                    <div class="container">
                        <form class="bootstrap-form-with-validation">
                            <h3 class="text-left">Recomendations </h3>
                            <div class="form-group"></div>
                            <div class="form-group">
                                <label class="control-label">Students Who Need Academic Advice</label>
                                <p class="form-static-control">The list below are students who did not do well in thier first semester</p>
                            </div>
                            <div class="form-group"></div>
                        </form>
                    </div>
                    <div class="container">
                        <div class="col-md-6">
                            <ul class="list-group">
                                <li class="list-group-item">
                                    <span>Vusie Maseko 180239043</span>
                                </li>
                                <li class="list-group-item">
                                    <span>Phinda Malaza180239009</span>
                                </li>
                                <li class="list-group-item">
                                    <span>Andile Dlamini 180239007</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="container">
                        <hr>
                    </div>
                    <div class="container">
                        <form class="bootstrap-form-with-validation">
                            <div class="form-group">
                                <label class="control-label" for="text-input">To:</label>
                                <input class="form-control" type="text" name="to_txt" placeholder="Enter Student ID" >
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="subject_txt">Subject Line</label>
                                <input class="form-control" type="text" name="subject_txt" placeholder="Academic Advice" id="subject_txt">
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="textarea-input">Textarea </label>
                                <textarea class="form-control" name="textarea-input" id="textarea-input"></textarea>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary" type="submit">Send Advice</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="tab-pane" role="tabpanel" id="tab-2">
                <div class="tab-content">
                <div class="tab-pane active" role="tabpanel" id="tab-1">
                    <div class="container">
                        <h3 class="text-left">Report Generation</h3>
                        <form class="bootstrap-form-with-validation" method="post" action="data-print.php">
                            <div class="form-group">
                                <label class="control-label" for="text-input">Select Student ID:</label>
                                <input class="form-control" type="text" name="studentID_txt" placeholder="Enter Student ID" >
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary" type="submit" name="print-btn">Generate Report</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>