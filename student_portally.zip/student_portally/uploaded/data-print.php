<html>
<head>
		<title>Student Report</title>
		
		<style>
				.container {
					width:75%;
					margin:auto;
				}
						
				.table {
				    width: 100%;
				    margin-bottom: 20px;
				}	

				.table-striped tbody > tr:nth-child(odd) > td,
				.table-striped tbody > tr:nth-child(odd) > th {
				    background-color: #f9f9f9;
				}

				@media print{
				#print {
					display:none;
				}
				}

				#print {
					width: 90px;
				    height: 30px;
				    font-size: 18px;
				    border-radius: 4px;
					margin-left:28px;
					cursor:hand;
				}
		
		</style>
		<script>
			function printPage() {
			    window.print();
			}
		</script>
		
</head>
<body>
	<div class = "container">
		<div id = "header">
			<br/>
			<button type="submit" id="print" onclick="printPage()">Print</button>
			<p style = "text-align: center; font-size:14pt; font-weight:bold;">STUDENTS REPORTS</p>
	        <div>
				<b style="">Date Prepared:</b>
				<?php include('current-date.php'); ?>
	        </div>			
			<br/>
			<table class="table table-striped">
				<thead>
					<tr>
						<th>RESULT ID</th>
						<th>YEAR ID</th>
						<th>EXAM ID</th>
						<th>RESULT %</th>
						<th>RESULT STATUS</th>
					</tr>
				</thead>   
				<tbody>
					<?php
						include ('connection.php');

						if(isset($_POST['print-btn'])){

							$student_id = $_POST['studentID_txt'];

							$sql = "SELECT * FROM result ";

							$result = $conn->query($sql);

							if ($result->num_rows > 0) {
								  // output data of each row
								while($row = $result->fetch_assoc()) {

								    echo "<tr><td align='center'>" . $row["RESULT_ID"]. "</td><td align='center'> " . $row["YEAR_ID"]."</td><td align='center'> " . $row["STUDENT_ID"]."</td><td align='center'> " . $row["RESULT_PERCENTAGE"]. "</td><td align='center'> " . $row["RESULT_STATUS"]. "</td></tr>";
								  }

								} else {
								  echo "0 results";
							}

						}else{
							echo "Lengcodvo yakho inani!!";
						}
					?>
				</tbody> 
			</table> 
			<br />
			<br />
		</div>
	</div>
</body>


</html>

