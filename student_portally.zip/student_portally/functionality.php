<?php



class alpha
{
	public $base_url = 'http://localhost/New/functionality/';
	public $connect;
	public $query;
	public $statement;
	public $now;

	function alpha()
	{
		$this->connect = new PDO("mysql:host=localhost;dbname=student portal", "root", "");

		session_start();

		$this->now = date("Y-m-d H:i:s",  STRTOTIME(date('h:i:sa')));
	}

	function execute($data = null)
	{
		$this->statement = $this->connect->prepare($this->query);
		if($data)
		{
			$this->statement->execute($data);
		}
		else
		{
			$this->statement->execute();
		}		
	}

	function row_count()
	{
		return $this->statement->rowCount();
	}

	function statement_result()
	{
		return $this->statement->fetchAll();
	}

	function get_result()
	{
		return $this->connect->query($this->query, PDO::FETCH_ASSOC);
	}

	function is_login()
	{
		if(isset($_SESSION['userID']))
		{
			return true;
		}
		return false;
	}

	function is_H_O_F()
	{
		if(isset($_SESSION['Access']))
		{
			if($_SESSION["Access"] == 'H.O.F')
			{
				return true;
			}
			return false;
		}
		return false;
	}

	function clean_input($string)
	{
	  	$string = trim($string);
	  	$string = stripslashes($string);
	  	$string = htmlspecialchars($string);
	  	return $string;
	}

	function Get_year_in($dep_code)
	{
		$this->query = "
		SELECT year FROM year_rp 
		WHERE dep_code = '$dep_code'
		";
		$result = $this->get_result();
		foreach($result as $row)
		{
			return $row["dep_name"];
		}
	}

	function Get_Course_name($dep_code)
	{
		$this->query = "
		SELECT course_name FROM course_rp 
		WHERE dep_code = '$dep_code' 
		AND course_status = 'Enable'
		";
		$result = $this->get_result();
		$data = array();
		foreach($result as $row)
		{
			$data[] = $row["course_name"];
		}
		return $data;
	}

	function Get_user_name($user_id)
	{
		$this->query = "
		SELECT * FROM user_rp 
		WHERE userID = '".$userID."'
		";
		$result = $this->get_result();
		foreach($result as $row)
		{
			if($row['Access'] != 'H0F')
			{
				return $row["userName"];
			}
			else
			{
				return 'H0F';
			}
		}
	}

	function Get_exam_name($exam_id)
	{
		$this->query = "
		SELECT exam_name FROM exam_rp 
		WHERE exam_id = '$exam_id'
		";
		$result = $this->get_result();
		foreach($result as $row)
		{
			return $row["exam_name"];
		}
	}

	
	function Get_total_classes()
	{
		$this->query = "
		SELECT COUNT(class_id) as Total 
		FROM class_srms 
		WHERE class_status = 'Enable'
		";
		$result = $this->get_result();
		foreach($result as $row)
		{
			return $row["Total"];
		}
	}

	function Get_total_subject()
	{
		$this->query = "
		SELECT COUNT(course_code) as Total 
		FROM course_rp 
		WHERE course _status = 'Enable'
		";
		$result = $this->get_result();
		foreach($result as $row)
		{
			return $row["Total"];
		}
	}

	function Get_total_student()
	{
		$this->query = "
		SELECT COUNT(student_id) as Total 
		FROM student_rp 
		WHERE student_status = 'Enable'
		";
		$result = $this->get_result();
		foreach($result as $row)
		{
			return $row["Total"];
		}
	}

	function Get_total_exam()
	{
		$this->query = "
		SELECT COUNT(exam_id) as Total 
		FROM exam_rp 
		WHERE exam_status = 'Enable' 
		";
		$result = $this->get_result();
		foreach($result as $row)
		{
			return $row["Total"];
		}
	}

	function Get_total_result()
	{
		$this->query = "
		SELECT COUNT(result_id) as Total 
		FROM result_rp 
		";
		$result = $this->get_result();
		foreach($result as $row)
		{
			return $row["Total"];
		}
	}

}


?>