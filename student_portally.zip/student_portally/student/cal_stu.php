<?php
include 'cal.php';


    include("connection.php");


?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
    <link href="calendar.css" rel="stylesheet" type="text/css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">180239003 </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
             <?php  
         
                    $sql_get = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                    $count = mysqli_num_rows($sql_get);

            ?>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                   <li role="presentation"><a class="text-muted bg-warning" href="Student profile.php">Student Profile</a></li>
                       <li role="presentation"><a href="cal_stu.php"> Calender</a></li>
                    <li role="presentation"><a href="assess_student.php">Assessments </a></li>
                    <li role="presentation"><a href="RP.php"> Reports</a></li>
                        <li role="presentation"><a href="NOT CM STU final.php" class="custom-navbar"> Inbox<span class="badge" ><?php echo $count; ?> </span></a></li>
                    <li class="dropdown open">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" href="#"> <span class="caret"></span></a>
                        <ul class="dropdown-menu dropdown-menu" role="menu">
                            <?php
                                    $sql_get1 = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                                    if(mysqli_num_rows($sql_get1)) 
                                    {
                                        while ($result =mysqli_fetch_assoc($sql_get1))
                                         {
                                           /* echo '<li role="presentation" class="active"  text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].'"> '.$result['message'].'  </a></li>'; -->  */
                                            echo '<a class="dropdown-item" text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].' ">'.$result['message']. '</a></li>';
                                           echo '<div class ="dropdown-divider"></div>';
                                        }
                                    }else
                                    {
                                        echo '<a class="dropdown-item" text="primary" class="active" text="danger" font="bold">Sorry no new messages </a></li>';
                                    }


                            ?>
                            <!--li role="presentation" class="active">Logout</a></li>
                            <li role="presentation" class="active">Logout </a></li-->

                        </ul>
                    </li>
                                    </ul>

                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            <li role="presentation"><a href="#">Settings </a></li>
                            <li role="presentation"><a href="#">Payments </a></li>
                            <li role="presentation" class="active"><a href="#">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <h1 class="text-center">Calender</h1>
    <hr>
    <div class="container">
       
     
    
    <div class="container">
        <br>
     <?=$calendar?>
    </div>
    <div class="container">
        <hr>



    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>