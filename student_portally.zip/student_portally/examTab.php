
<?php 
   include "connection.php";

        session_start();
    if (empty($_SESSION['user_id'])){
        header("location: LOGINPAGE.php");
        exit();
    }

 ?>





<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#"><?php echo $_SESSION['user_id']; ?></a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <?php  
         
                    $sql_get = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                    $count = mysqli_num_rows($sql_get);

            ?>

            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a class="text-muted bg-warning" href="find_student.php">Find A Student</a></li>
                    <li role="presentation"><a href="assess_lecturer.php">Assessments </a></li>
                    <li role="presentation"><a href="cal_lect.php">Add Event </a></li>
                    <li role="presentation"><a href="resultSheet.php"> Reports</a></li>
                    <li role="presentation"><a href="NOT CB LECT.php" class="custom-navbar">  Notification <span class="badge" ><?php echo $count; ?> </span></a></li>
                    <li><li class="dropdown open">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" href="#"> <span class="caret"></span></a>
                        <ul class="dropdown-menu dropdown-menu" role="menu">
                            <?php
                                    $sql_get1 = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                                    if(mysqli_num_rows($sql_get1)) 
                                    {
                                        while ($result =mysqli_fetch_assoc($sql_get1))
                                         {
                                           /* echo '<li role="presentation" class="active"  text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].'"> '.$result['message'].'  </a></li>'; -->  */
                                            echo '<a class="dropdown-item" text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].' ">'.$result['message']. '</a></li>';
                                           echo '<div class ="dropdown-divider"></div>';
                                        }
                                    }else
                                    {
                                        echo '<a class="dropdown-item" text="primary" class="active" text="danger" font="bold">Sorry no new messages </a></li>';
                                    }


                            ?>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                              
                            <li role="presentation" class="active"><a href="LOGINPAGE.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Reports </h1>
    <hr>
    <div class="container">
        <div>
            <ul class="nav nav-tabs">
                
               <!--  -->
               <li ><a href="res.php" role="presentation" >Continuous Assesment</a></li>
                <li class="active"><a href="examTab.php" role="presentation" >Exam Mark</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" role="tabpanel" id="tab-1"></div>
                <div class="tab-pane" role="tabpanel" id="tab-2" href="examTab.php">
                    <p>Second tab content.</p>
                </div>
               
            </div>
        </div>
    </div>
    <div class="container">
        <hr>
    </div>
   
            
            </div>
        </div>
    </div>
    <div class="container">
        <hr>
    </div>
           

            <div class="main">
        <form action="" method="post">
            <fieldset>
        <legend style="color: blue;"><h2 class="text-center"><i class="glyphicon glyphicon-plus"></i> Record Exam Mark </h2></legend>  

            <div class="text-center">
            

                <?php
                    //include("init.php");
                   // include("session.php");

                    $select_class_query1="SELECT `StudentNumber` from `studentp`";
                    $class_result1=mysqli_query($conn,$select_class_query1);
                    //select Student ID
                    echo '<select name="Std_Num" >';
                    echo '<option selected disabled >Select Student ID</option>';
                    
                        while($row1 = mysqli_fetch_array($class_result1)) {
                            $display1=$row1['StudentNumber'];
                            echo '<option  value="'.$display1.'">'.$display1.'</option>';
                        }
                    echo'</select>';                      
                ?>

                <?php
                    //include("init.php");
                   // include("session.php");

                    $select_class_query="SELECT `course_code` from `course`";
                    $class_result=mysqli_query($conn,$select_class_query);
                    //select class
                    echo '<select name="class_name" >';
                    echo '<option selected disabled >Select Class</option>';
                    
                        while($row = mysqli_fetch_array($class_result)) {
                            $display=$row['course_code'];
                            echo '<option  value="'.$display.'">'.$display.'</option>';
                        }
                    echo'</select>';                      
                ?>

                 

               <!-- <input type="text" name="rno" placeholder="Roll No"> -->
                  <label for="birthday">Exam Date:</label>
                <input type="date" id="exam" name="ex1">
                <input type="text" name="p1" id="" placeholder="Exam Mark">
                <input type="submit" value="Submit">
                </div>
            </fieldset>
        </form>
    </div>



  
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>     
                

       
        <hr>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>


<?php
    if(isset($_POST['p1'],$_POST['p2'],$_POST['p3'],$_POST['p4'],$_POST['p5']))
    {
      //  $rno=$_POST['rno'];
        if(!isset($_POST['class_name']))
            $class_name=null;
        else
            $class_name=$_POST['class_name'];
            $Std_Num=$_POST['Std_Num'];
        $p1=(int)$_POST['p1'];
        $p2=(int)$_POST['p2'];
        $p3=(int)$_POST['p3'];
        $p4=(int)$_POST['p4'];
        $p5=(int)$_POST['p5'];

        $marks=$p1+$p2+$p3+$p4+$p5;
        $percentage=$marks/5;

        // validation
        if (empty($class_name) or empty($Std_Num) or $p1>100 or  $p2>100 or $p3>100 or $p4>100 or $p5>100 or $p1<0 or  $p2<0 or $p3<0 or $p4<0 or $p5<0 ) {
            if(empty($class_name))
                echo '<p class="error">Please select class</p>';
            if(empty($Std_Num))
                echo '<p class="error">Please enter Student number</p>';
            if(preg_match("/[a-z]/i",$Std_Num))
                echo '<p class="error">Please enter valid roll number</p>';
            if(preg_match("/[a-z]/i",$marks))
                echo '<p class="error">Please enter valid marks</p>';
            if($p1>100 or  $p2>100 or $p3>100 or $p4>100 or $p5>100 or $p1<0 or  $p2<0 or $p3<0 or $p4<0 or $p5<0)
                echo '<p class="error">Please enter valid marks</p>';
            exit();
        }

        $name=mysqli_query($conn,"SELECT * FROM `studentp` WHERE `StudentNumber`='$Std_Num'");
        while($row = mysqli_fetch_array($name)) {
            $display=$row['FirstName'];
            $display12=$row['LastName'];
            echo $display;
            echo $display12;
          
         }


        $sql="INSERT INTO `quiz_table` (`student_id`, `course_code`,`FirstName`, `LastName`, `quiz1`, `quiz2`, `quiz3`, `quiz4`, `quiz5`, `marks`, `percentage`) VALUES ('$Std_Num', '$class_name','$display','$display12','$p1', '$p2', '$p3', '$p4', '$p5', '$marks', '$percentage')";
        $sql=mysqli_query($conn,$sql);

        if (!$sql) {
            echo '<script language="javascript">';
            echo 'alert("Invalid Details")';
            echo '</script>';
        }
        else{
            echo '<script language="javascript">';
            echo 'alert("Successful")';
            echo '</script>';
        }
    }
?>