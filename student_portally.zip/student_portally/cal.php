<?php
include 'Calendar.php';

$conn = new mysqli("localhost", "root","","student portal");
$calendar = new Calendar('2021-06-04');


if (isset($_POST['submit'])) {
$date = $_POST['event_date'];
$txt = $_POST['event_name'];
$days = $_POST['event_days'];
$color = $_POST['event_color'];
$posts = array();




$calendar->add_event($_POST['event_name'],$_POST['event_date'] , $_POST['event_days'], $_POST['event_color']);

 //"INSERT INTO `student portal`.`event_table` ( `event_name`, `event_date`, `event_days`, `event_color`) VALUES ('exams', '2021-02-11', '4', 'red')";
$sql= "INSERT INTO event_table (event_date,event_name,event_days,event_color) VALUES ('$date','$txt','$days','$color')";
$result = $conn->query($sql);

$sql= "INSERT INTO event_table (event_date,event_name,event_days,event_color) VALUES ('$date','$txt','$days','$color')";
$result = $conn->query($sql);
 $sqli = mysqli_query($conn,"SELECT*FROM event_table");
    if(isset($_GET['event_table'])){

        foreach ($sqli as $event_id) {
            $calendar->add_event($_GET[$txt['event_name']], $_GET[$date['event_date']], $_GET[$days['event_days']], $_GET[$color['event_color']]);
        }

    }

 }
$calendar->add_event('Exams Week', '2021-06-21', 4, 'red');

$conn->close();

?>