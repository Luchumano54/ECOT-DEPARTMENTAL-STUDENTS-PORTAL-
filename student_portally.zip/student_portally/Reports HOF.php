<?php

    include("connection.php");

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg" style="width: 100%;">
   <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
             <?php

                session_start();
                 if (empty($_SESSION['user_id'])){
                    header("location: LOGINPAGE.php");
                    exit();
                }
            ?>
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#"><?php echo $_SESSION['user_id']; ?> </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <?php  
         
                    $sql_get = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                    $count = mysqli_num_rows($sql_get);

            ?>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a class="text-muted bg-warning" href="FAS HOF.php">Find A Student</a></li>
                      <li role="presentation"><a href="add_student_final.php"> Add A Student</a></li>
                     <li role="presentation"><a href="Reports HOF.php"> Reports</a></li>
                     <li role="presentation"><a href="addevent.php">Add Event</a></li>
                    <li role="presentation"><a href="NOT IB HOF.php" class="custom-navbar">  Notification <span class="badge" ><?php echo $count; ?> </span></a></li>
                    <li><li class="dropdown open">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" href="#"> <span class="caret"></span></a>
                        <ul class="dropdown-menu dropdown-menu" role="menu">
                            <?php
                                    $sql_get1 = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                                    if(mysqli_num_rows($sql_get1)) 
                                    {
                                        while ($result =mysqli_fetch_assoc($sql_get1))
                                         {
                                           /* echo '<li role="presentation" class="active"  text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].'"> '.$result['message'].'  </a></li>'; -->  */
                                            echo '<a class="dropdown-item" text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].' ">'.$result['message']. '</a></li>';
                                           echo '<div class ="dropdown-divider"></div>';
                                        }
                                    }else
                                    {
                                        echo '<a class="dropdown-item" text="primary" class="active" text="danger" font="bold">Sorry no new messages </a></li>';
                                    }


                            ?>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            <!--li role="presentation"><a href="#">Settings </a></li>
                            <li role="presentation"><a href="#">Payments </a></li-->
                            <li role="presentation" class="active"><a href="LOGINPAGE.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Reports </h1>
    <hr>
    <div class="container">
        <div>
            <ul class="nav nav-tabs">
                <li class="active"><a href="#tab-1" role="tab" data-toggle="tab">Recommendations </a></li>
                <li><a href="#tab-2" role="tab" data-toggle="tab">Generate Report</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" role="tabpanel" id="tab-1">
                    <div class="container">
                    	<br>
                    	<h4>Below Students needs Recommendations</h4>
                    		<?php
                                include("connection.php");
                                $pass_mark = 49;
                                $sql = "SELECT * FROM ca_table where ca <= ".$pass_mark;

                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                  // output data of each row

                                echo "<table class='table table-striped'>
                                <thead>
                                <tr>
                                    <td align='center'>STUDENT ID</td>
                                    <td align='center'> COURSE CODE</td>
                                    <td align='center'> AVERAGE CA</td>
                                    <td align='center'> STATUS</td>
                                </tr>
                                </thead>
                                <tbody>";
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr><td align='center'>" . $row["student_id"]. "</td><td align='center'> " . $row["course_code"]."</td><td align='center'> " . $row["ca"]."</td><td align='center'> " . 'FAILED'. "</td></tr>";
                                    }
                                   echo " </tbody>
                                    </table>";
                                    } else {
                                  echo "0 results";
                                }
                            ?>
                            <br>
                            <hr>
                    </div>
                    <div class="container">
                    	
                    	<h4>Send A Recommendation Message</h4>
				        <form class="bootstrap-form-with-validation" method="post" action="sendMessage.php">
				            <div class="form-group">
				                <label class="control-label" for="text-input">To:</label>
				                <input class="form-control" type="text" name="send_to" placeholder="Enter Student ID">
				            </div>
				            
				            <div class="form-group">
				                <label class="control-label" for="password-input">Subject Line</label>
				                <input class="form-control" type="text" name="tittle_txt" placeholder="Academic Advice" id="password-input">
				            </div>
				            <div class="form-group">
				                <label class="control-label" for="textarea-input">Textarea </label>
				                <textarea class="form-control" name="message_txt" id="textarea-input" placeholder="Enter your message"></textarea>
				            </div>
				            <div class="form-group">
				                <button class="btn btn-primary" type="submit" name="submit">Send Advice </button>
				            </div>
				        </form>
                    </div>
                </div>
                <div class="tab-pane" role="tabpanel" id="tab-2">
                <div class="tab-content">
                <div class="tab-pane active" role="tabpanel" id="tab-1">
                    <div class="container">
                        <h3 class="text-left">Report Generation</h3>
                        <form class="bootstrap-form-with-validation" method="post" action="data-printHOF.php">
                            <div class="form-group">
                                <label class="control-label" for="text-input">Select Student ID:</label>
                                <input class="form-control" type="text" name="studentID_txt" placeholder="Enter Student ID" >
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary" type="submit" name="print-btn">Generate Report</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
