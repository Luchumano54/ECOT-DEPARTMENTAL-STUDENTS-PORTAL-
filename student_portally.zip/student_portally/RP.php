<!DOCTYPE html>
<html>

<head>
  <?php
                session_start();
                 if (empty($_SESSION['user_id'])){
                    header("location: LOGINPAGE.php");
                    exit();
    }
            ?>
<?php
include("connection.php");
include('functionality.php');
//$object = new alpha();

?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body>
    <img class="img-responsive" src="assets/img/FINALv2.jpg" style="width: 100%;">
     <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
           
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="Student profile.php"><?php echo $_SESSION['user_id']; ?> </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>

            <?php  
         
                    $sql_get = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                    $count = mysqli_num_rows($sql_get);

            ?>

            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a href="AS STUDENT ASSIGN.php">Assessments </a></li>
                    <li role="presentation"><a href="cal_stu.php">Calender </a></li>
                    <li role="presentation"><a href="RP.php"> Reports</a></li>
                     <li role="presentation"><a href="NOT CM STU final.php" class="custom-navbar"> Notification <span class="badge" ><?php echo $count; ?> </span></a></li>
                    <li><li class="dropdown open">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" href="#"> <span class="caret"></span></a>
                        <ul class="dropdown-menu dropdown-menu" role="menu">
                            <?php
                                    $sql_get1 = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                                    if(mysqli_num_rows($sql_get1)) 
                                    {
                                        while ($result =mysqli_fetch_assoc($sql_get1))
                                         {
                                           /* echo '<li role="presentation" class="active"  text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].'"> '.$result['message'].'  </a></li>'; -->  */
                                            echo '<a class="dropdown-item" text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].' ">'.$result['message']. '</a></li>';
                                           echo '<div class ="dropdown-divider"></div>';
                                        }
                                    }else
                                    {
                                        echo '<a class="dropdown-item" text="primary" class="active" text="danger" font="bold">Sorry no new messages </a></li>';
                                    }


                            ?>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                           
                            <li role="presentation" class="active"><a href="LOGINPAGE.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Reports </h1>
    <hr>
    <div class="container">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#tab-1" role="tab" data-toggle="tab">Continuous Assessment</a></li>
            <li><a href="#tab-2" role="tab" data-toggle="tab">Final Report</a></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane active" role="tabpanel" id="tab-1">
                <div class="card ">
                    <div class="card-body" style="padding: 1%;">
                        <h2 class="text-center" style="font-weight: bold;">ESWATINI COLLEGE OF TECHNOLOGY</h2>
                        <div>
                            <center><img class="img-fluid" src="assets/img/ECZOT.jpg" style="height: 150px; width: 150px;"></center>
                        </div>

                        <div class="text-center">
                           <h5>FACULTY OF INFORMATION COMMUNICATION AND TECHNOLOGY</h5>
                        </div>
                        <br/>
                        <br/>
                        <div>
                            <h5 style="float: right;"><b>Date:&nbsp;<?php include('current-date.php'); ?></b></h5>
                           <h5><b>Student ID:&nbsp;<?php echo $_SESSION['user_id']; ?></b></h5>
                        </div>
                        <br/>
                        <br/>
                        <div id="Assignments">
                            <h3>Assignments</h3>
                            <?php
                                include("connection.php");
                                $sql = "SELECT * FROM assignment_table where student_id = ".$_SESSION['user_id'];

                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                  // output data of each row
                                echo "<table class='table table-striped'>
                                <thead>
                                <tr>
                                    <td align='center'>Course Code</td>
                                    <td align='center'>Assignment 1</td>
                                    <td align='center'>Assignment 2</td>
                                    <td align='center'>Assignment 3</td>
                                    <td align='center'>Assignment 4</td>
                                    <td align='center'>Average</td>
                                </tr>
                                </thead>
                                <tbody>";
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr><td align='center'>" . $row["course_code"]. "</td><td align='center'> " . $row["assignment1"]."</td><td align='center'> " . $row["assignment2"]."</td><td align='center'> " . $row["assignment3"]."</td><td align='center'> " . $row["assignment4"]. "</td><td align='center'> " . $row["assigAverage"]. "</td></tr>";
                                    
                                    }
                                   echo " </tbody>
                                    </table>";
                                    } else {
                                  echo "0 results";
                                }
                            ?>
                        </div>
                        <div id="Quiz">
                            <h3>Quiz</h3>
                            <?php
                                include("connection.php");

                                $sql = "SELECT * FROM quiz_table where student_id = ".$_SESSION['user_id'];

                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                  // output data of each row
                                echo "<table class='table table-striped'>
                                <thead>
                                <tr>
                                    <td align='center'>Course Code</td>
                                    <td align='center'>Quiz 1</td>
                                    <td align='center'>Quiz 2</td>
                                    <td align='center'>Quiz 3</td>
                                    <td align='center'>Quiz 4</td>
                                    <td align='center'>Average</td>
                                </tr>
                                </thead>
                                <tbody>";
                                while($row = $result->fetch_assoc()) {
                                   echo "<tr><td align='center'>" . $row["course_code"]. "</td><td align='center'> " . $row["quiz1"]."</td><td align='center'> " . $row["quiz2"]."</td><td align='center'> " . $row["quiz3"]."</td><td align='center'> " . $row["quiz4"]. "</td><td align='center'> " . $row["quizAverage"]. "</td></tr>";
                                    
                                    }
                                   echo " </tbody>
                                    </table>";
                                    } else {
                                  echo "0 results";
                                }
                            ?>
                        </div>
                        <div id="test">
                            <h3>Tests</h3>
                            <?php
                                include("connection.php");

                                $sql = "SELECT * FROM test_table where user_id = ".$_SESSION['user_id'];

                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                  // output data of each row
                                echo "<table class='table table-striped'>
                                <thead>
                                <tr>
                                    <td align='center'>Course Code</td>
                                    <td align='center'>Test 1</td>
                                    <td align='center'>Test 2</td>
                                    <td align='center'>Test 3</td>
                                    <td align='center'>Test 4</td>
                                    <td align='center'>Average</td>
                                </tr>
                                </thead>
                                <tbody>";
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr><td align='center'>" . $row["course_code"]. "</td><td align='center'> " . $row["tes1"]."</td><td align='center'> " . $row["tes2"]."</td><td align='center'> " . $row["tes3"]."</td><td align='center'> " . $row["tes4"]. "</td><td align='center'> " . $row["aveTest"]. "</td></tr>";
                                    }
                                   echo " </tbody>
                                    </table>";
                                    } else {
                                  echo "0 results";
                                }
                            ?>
                        </div>
                        <br/>
                        <br/>
                    </div>
                </div>
            </div>
            <div class="tab-pane" role="tabpanel" id="tab-2">
                <div class="card ">
                    <div class="card-body" style="padding: 1%;">
                        <h2 class="text-center" style="font-weight: bold;">ESWATINI COLLEGE OF TECHNOLOGY</h2>
                        <div>
                            <center><img class="img-fluid" src="assets/img/ECZOT.jpg" style="height: 150px; width: 150px;"></center>
                        </div>

                        <div class="text-center">
                           <h5>FACULTY OF INFORMATION COMMUNICATION AND TECHNOLOGY</h5>
                        </div>
                        <br/>
                        <br/>
                        <div>
                            <h5 style="float: right;"><b>Date:&nbsp;<?php include('current-date.php'); ?></b></h5>
                           <h5><b>Student ID:&nbsp;<?php echo $_SESSION['user_id']; ?></b></h5>
                        </div>
                        <br/>
                        <br/>
                        <div id="Assignments">
                            <h3></h3>
                            <?php
                                include("connection.php");
                                $sql = "SELECT * FROM ca_table where student_id = ".$_SESSION['user_id'];

                                /*$result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                  // output data of each row
                                echo "<table class='table table-striped'>
                                <thead>
                                <tr>
                                    <td align='center'>Course Code</td>
                                    <td align='center'> CA Mark</td>
                                    <td align='center'>Exam Mark</td>
                                    <td align='center'>Final Mark</td>
                                    <td align='center'>Status</td>
                                </tr>
                                </thead>
                                <tbody>";
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr><td align='center'>" . $row["course_code"]. "</td><td align='center'> " . $row["assignment1"]."</td><td align='center'> " . $row["assignment2"]."</td><td align='center'> " . $row["assignment3"]."</td><td align='center'> " . $row["assignment4"]. "</td><td align='center'> " . $row["assigAverage"]. "</td></tr>";
                                    
                                    }
                                   echo " </tbody>
                                    </table>";
                                    } else {
                                  echo "0 results";
                                }*/
                            ?>
                        </div>
                        <div >
                            <form method="post" action="data-printSTD.php">
                                <div class="form-group">
                                    <center><input type="submit" value="Generate Report"  class="btn btn-primary" ></center>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>