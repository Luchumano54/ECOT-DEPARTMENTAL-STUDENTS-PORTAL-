<?php
	error_reporting(0);
	include 'connection.php';
	session_start(); // Starting Session
	$error=''; // Variable To Store Error Message
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		if (empty($_POST['user_id']) || empty($_POST['user_password'])) {
			$error = "Username or Password is empty";
		}
		else {
			$id = $_POST['user_id'];
			$passwd = $_POST['user_password'];

			$id = stripslashes($id);
			$passwd = stripslashes($passwd);
			$id = mysql_real_escape_string($id);
			$passwd = mysql_real_escape_string($passwd);

			// SQL query to fetch information of registerd users and finds user match.
			$query = "CALL Login('$email','$passwd')";

			$table = mysqli_query($connection,$query);

			if($table){
				$rows=mysqli_num_rows($table);
				if($rows == 1){
			    	$row = mysqli_fetch_assoc($table);
					$_SESSION['user_id'] = $row['user_id'];
					$_SESSION['user_name'] = $row['user_name'];
					//$_SESSION['name'] = $row['name'];
					$_SESSION['user_email'] = $row['user_email'];
					$_SESSION['user_type'] = $row['user_type'];
					//$_SESSION['company_name'] = $row['company_name'];
					//$_SESSION['institute_name'] = $row['institute_name'];
					$_SESSION['user_phone'] = $row['user_phone'];
					$_SESSION['dp_url'] = $row['profile_image'];
					setcookie("dp_url", $_SESSION['dp_url']);
					setcookie("user_name", $_SESSION['user_name']);
					header("location:  cal_stu.php?user=".$_SESSION['user_id']);

					exit();
				}
				else {
					$error = "Username or Password is invalid";
				}
			} 
			mysql_close($connection); // Closing Connection
		}
		header("location: cal_stu.php");
		//header("location: index.php?error=$error"); // Redirecting To Other Page
	}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg">
    <div class="login-card"><img src="assets/img/ECZOT.jpg" class="profile-img-card">
        <p class="profile-name-card">WELCOME TO OUR IT DEPARTMENT</p>
        <form class="form-signin" action="<?=$_SERVER['PHP_SELF'] ?>   " method="post" class="p-4" name="Log"><span class="reauth-email">
         
         </span>
            <input class="form-control" type="varchar" required="" placeholder="User ID" autofocus="" name="user_id" id="user_id" maxlength="10" minlength="9">
            <input class="form-control" type="password" required="" placeholder="Password" name= "user_password" id="user_password" maxlength="5" minlength="5">
           <div class="radio">
                <div class="radio">
                    <!----<label for="user_type"> I'm a :</label>
                        <<input type="radio" name="user_type" value="Student" class=custom-radio required>&nbsp;Student|
                        <input type="radio" name="user_type" value="Lecturer" class=custom-radio required>&nbsp;Lecturer|
                        <input type="radio" name="user_type" value="H.O.F" class=custom-radio required>&nbsp;H.O.F--->
                </div>
            </div>
            <button class="btn btn-primary btn-block btn-lg btn-signin" type="submit" name="Log">Sign in</button>
            <h5 class="text-danger"><?echo (isset($msg))? $msg:""; ?></h5>
        </form><a href="#" class="forgot-password">Forgot your password?</a></div>
    <div></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>