<?php 
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
  session_start();

 /* $host = "localhost";
  $user_id = "root";
  $password = "";
  $dbname = "Student portal";
  */


$mysqli = new mysqli("localhost", "root","","Student portal");

$sql = ("SELECT `user_id`,`user_name` FROM `user` WHERE `user_id`=\"".$_POST["user_id"]."\" AND `user_password`=\"".$_POST["user_password"]."\"");
  $result = mysqli_query($mysqli,$sql);
  $row = mysqli_fetch_assoc($result);
//$row = $row[0];
//var_dump($row);
 /* $conn = new mysqli("localhost", "root","","Student portal");
  $msg = "";
 
//try {
    //$conn = new PDO("mysql:host=localhost;dbname=Student portal", $user_id, $password);
     
    //$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if(isset($_POST['LOGIN'])){
      $user_id = $_POST['user_id'];
      $user_password = $_POST['user_password'];
      $user_password = sha1($user_password);
   //
    $user_type = $_POST['user_type'];

   $sql = "SELECT * FROM user WHERE user_id=? AND user_password=? AND user_type=?";
   $results = $conn->query($sql);

   var_dump($results->fetch_assoc());
 }

  $stmt =$conn->prepare($sql);
$stmt->close();
   $stmt->bind_param("sss",$user_id,$user_password,$user_type);
   $stmt->execute();
   $result = $stmt->get_result();
   $row = $sql->fetch_assoc();
*/
 //var_dump($row["user_type"]);
  // session_regenerate_id();

  $_SESSION['user_id'] = $row['user_id'] ;
  $_SESSION['user_type'] = $row['user_type'];
  session_write_close();

   if($result->num_rows==1 && $_SESSION['user_type']=="Student"){
    //header("location: FAS HOF.html");
    echo "student ";
   }
    else if($result->num_rows==1 && $_SESSION['user_type']=="Lecturer"){
    //header("location.lect.php");
      echo "Lecturer ";
    } 
    else if($result->num_rows==1 && $_SESSION['user_type']=="H.O.F") {
    //header("location:hoof.php");
      echo "HOF";
    }
    else{
         $msg = "Username or Password is Incorrect!";
    }
 // } 
//    }
/*catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }*/

 ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg">
    <div class="login-card"><img src="assets/img/ECZOT.jpg" class="profile-img-card">
        <p class="profile-name-card">WELCOME TO OUR IT DEPARTMENT</p>
        <form class="form-signin" action="<?=$_SERVER['PHP_SELF'] ?>   " method="post" class="p-4"><span class="reauth-email">
         
         </span>
            <input class="form-control" type="varchar" required="" placeholder="User ID" autofocus="" name="user_id" id="user_id">
            <input class="form-control" type="password" required="" placeholder="Password" name= "user_password" id="user_password">
           <div class="radio">
                <div class="radio">
                    <!----<label for="user_type"> I'm a :</label>
                        <<input type="radio" name="user_type" value="Student" class=custom-radio required>&nbsp;Student|
                        <input type="radio" name="user_type" value="Lecturer" class=custom-radio required>&nbsp;Lecturer|
                        <input type="radio" name="user_type" value="H.O.F" class=custom-radio required>&nbsp;H.O.F--->
                </div>
            </div>
            <button class="btn btn-primary btn-block btn-lg btn-signin" type="submit" name="LOGIN">Sign in</button>
            <h5 class="text-danger"><?=$msg; ?></h5>
        </form><a href="#" class="forgot-password">Forgot your password?</a></div>
    <div></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>