


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">Mr Dlamini</a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <!---<li role="presentation"><a class="text-muted bg-warning" href="#">Find A Student</a></li>-->
                    <li role="presentation"><a href="..\Assessment 2.php">Assessments </a></li>
                    <li role="presentation"><a href="..\RP.php"> Reports</a></li>
                    <li role="presentation"><a href="#" class="custom-navbar"> Inbox<span class="badge">10 </span></a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            <li role="presentation"><a href="#">Settings </a></li>
                            <li role="presentation"><a href="#">Payments </a></li>
                            <li role="presentation" class="active"><a href="../New/Logout.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Find A Student</h1>
    <hr>
    <div class="container">
        <form class="bootstrap-form-with-validation">
            <div class="form-group">
                <label class="control-label" for="search-input">Search Student</label>
                <div class="input-group">
                    <div class="input-group-addon"><span> <i class="glyphicon glyphicon-search"></i></span></div>
                    <input class="form-control" type="search" name="search-input" placeholder="Student ID eg. 180239003" id="search-input">
                </div>
            </div>
            <div class="form-group"></div>
            <div class="form-group">
                <button class="btn btn-primary" type="submit">View Student Profile</button>
            </div>
        </form>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <?php
if(isset($_GET["stu_fname"])){
    $User_Name = $_GET['stu_fname'];
    mysql_connect("localhost","root","") or die("Couldn't connect to database");
    mysql_select_db("studentt") or die ("That database could not be found");
    $userquery= mysql_query("SELECT * FROM studentt WHERE fname='$stu_fname'") or die ("The query could not be compleated. Please try again later ")
     if (mysql_num_rows($userquery) !=1){
        die ("That username could not be found!");
 }
 while($row = mysql_fetch_array($userquery, MYSQL_ASSOC)){
    $stu_num = $row['stu_num'];
    $stu_fname = $row['stu_fname'];
    $stu_lname = $row['stu_lname'];
    $stu_initials = $row['stu_initilas'];
    $stu_gender = $row['stu_gender'];
    $stu_dob = $row['stu_dob'];
    $stu_phone = $row['stu_phone'];
    $dep_code = $row['dep_code'];
    $c_code = $row['c_code'];
    $program = $row ['program'];
    $ca = $row['ca'];
}
if($stu_fname != $dbstu_fname){
    die("There has been an error. Please try again.");
}
?>
<?php
}else die ("You need to put correct fname!");
?>
</body>

</html>