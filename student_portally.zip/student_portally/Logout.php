<!DOCTYPE html>
<html>

<head>
	
</head>
<body>
<?php

session_start();

unset($_SESSION['user_id']);
unset($_SESSION['user_name']);
hearder('Location:index.php');
?>
</body>
</html>