


<?php

    include 'connection.php';

    if(isset($_POST['class_name'],$_POST['Std_Num']))
    {

        $class_name=$_POST['class_name'];
        $Std_Num=$_POST['Std_Num'];
        $assign1=(int)$_POST['assign1'];
        $assign2=(int)$_POST['assign2'];
        $assign3=(int)$_POST['assign3'];
        $assign4=(int)$_POST['assign4'];
        $assigAverage = ($assign1 + $assign2+$assign3+$assign4)/4;


        $sql="INSERT INTO `assignment_table` (`student_id`, `course_code`, `assignment1`, `assignment2`, `assignment3`, `assignment4`,assigAverage) VALUES ('$Std_Num', '$class_name','$assign1', '$assign2', '$assign3', '$assign4', '$assigAverage')";
        $sql=mysqli_query($conn,$sql);

        if (!$sql) {
            echo '<script language="javascript">';
            echo 'alert("Invalid Details")';
            echo '</script>';
            //call last added data


            
        }
        else{
            header ('Location: res.php');
            echo '<script language="javascript">';
            echo "New record created successfully";
            echo '</script>';
        }
    }else{
        echo "Select class name or student number!!";
    }
?>