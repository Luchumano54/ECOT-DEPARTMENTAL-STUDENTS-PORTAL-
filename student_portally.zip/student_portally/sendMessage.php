


<?php

    include 'connection.php';


        $send_to=(int)$_POST['send_to'];
        $tittle_txt=$_POST['tittle_txt'];
        $message=$_POST['message_txt'];
     
        $sql="INSERT INTO `send_message` (`send_to`, `tittle`, `message`) VALUES ($send_to, $tittle_txt,$message)";
        $sql=mysqli_query($conn,$sql);

        if (!$sql) {
           
            echo '<script language="javascript">';
            echo 'alert("Invalid Details")';
            echo '</script>';
        }
        else{
            header ('Location: Reports HOF.php.php');
            echo '<script language="javascript">';
            echo "New record created successfully";
            echo '</script>';
        }

?>