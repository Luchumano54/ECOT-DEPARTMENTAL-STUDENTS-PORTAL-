<?PHP

$male_status = 'unchecked';
$female_status = 'unchecked';

if (isset($_POST['Submit2'])) {

$selected_radio = $_POST['gender'];

if ($selected_radio = = 'male') {

$male_status = 'checked';

}
else if ($selected_radio = = 'female') {

$female_status = 'checked';

}

}

?>