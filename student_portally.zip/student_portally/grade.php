<?php


$conn = new mysqli("localhost", "root","","student portal");

if (isset($_POST['submit'])) {
	$StudentNumber = $_POST['Student_num'];
	$course_code = $_POST['course_code'];
	$Grade = $_POST['Grade'];


	$sql = "INSERT INTO result_sheet (Student_num,course_code,assignment) VALUES ('$StudentNumber','$course_code','$Grade')";


if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
 // header("location: resultSheet.php");

} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
}
$conn->close();
?>