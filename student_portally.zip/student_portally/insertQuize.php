


<?php

    include 'connection.php';

    if(isset($_POST['class_name'],$_POST['Std_Num']))
    {

        $class_name=$_POST['class_name'];
        $Std_Num=$_POST['Std_Num'];
        $quize1=(int)$_POST['quize1'];
        $quize2=(int)$_POST['quize2'];
        $quize3=(int)$_POST['quize3'];
        $quize4=(int)$_POST['quize4'];
        $quizAverage = (int)($quize1 + $quize2+$quize3+$quize4)/4;


        $sql="INSERT INTO `quiz_table` (`student_id`, `course_code`, `quiz1`, `quiz2`, `quiz3`, `quiz4`,quizAverage) VALUES ('$Std_Num', '$class_name','$quize1', '$quize2', '$quize3', '$quize4','$quizAverage')";
        $sql=mysqli_query($conn,$sql);

        if (!$sql) {
            echo '<script language="javascript">';
            echo 'alert("Invalid Details")';
            echo '</script>';
            //call last added data
            


            
        }
        else{
            header('Location: res.php');

            echo '<script language="javascript">';
            echo "New record created successfully";
            echo '</script>';
        }
    }else{
        echo "Select class name or student number!!";
    }
?>