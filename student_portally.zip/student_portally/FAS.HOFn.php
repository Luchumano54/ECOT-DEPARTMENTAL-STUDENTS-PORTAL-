
<?php
/***
$conn = new mysqli("localhost", "root","","Student portal");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);






if (isset($_POST['submit'])) {
    $StudentNumber = $_POST['StudentNumber'];
    $FirstName = $_POST['FirstName'];
    $LastName = $_POST['LastName'];
    $PhoneNum =$_POST['PhoneNum'];
    $passwordd =$_POST['passwordd'];
    $Gender = $_POST['Gender'];
  $datee = $_POST['datee'];
  $course =$_POST['course'];
    


$sql = "INSERT INTO studentp (StudentNumber,FirstName,LastName,PhoneNum,passwordd,Gender,datee,course) VALUES ('$StudentNumber','$FirstName','$LastName','$PhoneNum',$passwordd,'$Gender','$datee','$course')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

} ***/
include('addStudent.php');
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">Ms Dlamini</a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a class="text-muted bg-warning" href="#">Find A Student</a></li>
                    <li role="presentation"><a href="#">Assessments </a></li>
                    <li role="presentation"><a href="..\New\RP.php"> Reports</a></li>
                    <li role="presentation"><a href="..\New\NOT CM HOF.php" class="custom-navbar"> Notifications<span class="badge">10 </span></a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            <li role="presentation"><a href="#">Settings </a></li>
                            <li role="presentation"><a href="#">Payments </a></li>
                            <li role="presentation" class="active"><a href="#">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
   
    <div class="container">
        <form class="bootstrap-form-with-validation"    method="post" action="addStudent.php" >
            <h2 class="text-center"><i class="glyphicon glyphicon-plus"></i> Add new student</h2>
           
            
                <div class="form-group">
                <label class="control-label" for="text-input">Student Number</label>
                <input class="form-control" type="text" name="StudentNumber" id="StudentNumber" required="">

            <div class="form-group">
                <label class="control-label" for="text-input">First Name</label>

                <input class="form-control" type="text" name="FirstName" id="FirstName" required="">
            </div>
            <div class="form-group">
                <label class="control-label" for="text-input">Last Name</label>
                <input class="form-control" type="text" name="LastName" id="LastName" required="">
                </div>
                <div class="form-group"><label class="control-label" for="password-input">new password</label>
                <input class="form-control" type="varchar" name="passwordd" id="passwordd" required="">
            </div>
              <div class="form-group">
                <label class="control-label" for="text-input">phone Number</label>
                <input class="form-control" type="text" name="PhoneNum" id="PhoneNum" required="">
            </div>
            
              <form name="form1" method="post" action="raddG.php">
                <hr>
                <label class="control-label" for="email-input" id="Gender">Gender </label>
                <div class="radio">
                    <label class="control-label" required="">
                        <input type="radio" name="Gender" id="Male" value="m">Male</label>
                
            
                <label>
                    <input type="radio" name="Gender" id="Female" value="f">Female</label>
            </form>
            <hr>
            <div class="form-group">
                <label class="control-label" for="date">Date Of Birth</label>
            </div>
            <input class="form-control" type="date" name="datee" id="datee" required="">
            <div class="form-group"></div>
            
                  <form name="form1" method="post" action="raddC.php">
                <hr>
                <label class="control-label" for="email-input" id="course"> Course </label>
                <div class="radio">
                    <label class="control-label" required="">
                        <input type="radio" name="course" id="DCS100" value="DCS100">DCS100</label>
                
            
                <label>
                    <input type="radio" name="course" id="DCS200" value="DCS200">DCS200</label>
                <label>

                    <input type="radio" name="course" id="DCS300" value="DCS300">DCS300</label>
            </form>

            
            
            </div>
            <div class="form-group">
                <div class="checkbox">
                
            </div>
            <div class="form-group">
                 
                <button action ="$_POST" name="submit" id="submit" type="submit"  class="btn btn-primary">Done </button>

                
            </div>
        </form>
        
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>