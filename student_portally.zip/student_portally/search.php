<?php
error_reporting(0);
$conn = mysqli_connect("localhost","root","","student portal");
if(count($_POST)>0) {
$StudentNumber=$_POST[StudentNumber];
$result = mysqli_query($conn,"SELECT * FROM student where StudentNumber='$StudentNumber' ");
}
?>
<!DOCTYPE html>
<html>
<head>
<title> Retrive data</title>
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>
<table>
<tr>
	<td>Name</td>
<td>Email</td>
<td>Roll No</td>

</tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
<td><?php echo $row["FirstName"]; ?></td>
<td><?php echo $row["LastName"]; ?></td>
<td><?php echo $row["Gender"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
</body>
</html>