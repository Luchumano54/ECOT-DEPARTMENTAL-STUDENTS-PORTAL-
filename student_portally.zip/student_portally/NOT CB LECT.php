<?php
include('connection.php');
 


if(isset($_POST['Send'])){

    $choose= $_POST['send_to'];
    $name = $_POST['name'];
    $message = $_POST['message'];
    $date = date('y-m-d h:i:s');
    $sql = mysqli_query($conn,"INSERT INTO notification(send_to, name, message, date) VALUES ('$choose', '$name','$message','$date') ");
    if($sql)
    {
            echo "<script>alert('message sent successful;')</script>";
       }
       else
        { 
            echo mysqli_error($conn);
            exit;
    }
}

?>
<?php
if(isset($_POST['Sendto'])){

    $send_to = $_POST['send_to'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    $date = date('y-m-d h:i:s');
    $sql = mysqli_query($conn,"INSERT INTO send_message(send_to,tittle ,message, date) VALUES ('$send_to','$subject','$message','$date') ");
    if($sql)
    {
            echo "<script>alert('message sent successful;')</script>";
       }
       else
        { 
            echo mysqli_error($conn);
            exit;
    }
}
         session_start();
    if (empty($_SESSION['user_id'])){
        header("location: LOGINPAGE.php");
        exit();
    }
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg" style="width: 100%;">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#"><?php echo $_SESSION['user_id']; ?> </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <?php  
         
                    $sql_get = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                    $count = mysqli_num_rows($sql_get);

            ?>

            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a class="text-muted bg-warning" href="find_student.php">Find A Student</a></li>
                    <li role="presentation"><a href="assess_lecturer.php">Assessments </a></li>
                    <li role="presentation"><a href="cal_lect.php">Add Event </a></li>
                    <li role="presentation"><a href="res.php"> Reports</a></li>
                    <li role="presentation"><a href="NOT CB LECT.php" class="custom-navbar"> Notification <span class="badge" ><?php echo $count; ?> </span></a></li>
                    <li><li class="dropdown open">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" href="#"> <span class="caret"></span></a>
                        <ul class="dropdown-menu dropdown-menu" role="menu">
                            <?php
                                    $sql_get1 = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                                    if(mysqli_num_rows($sql_get1)) 
                                    {
                                        while ($result =mysqli_fetch_assoc($sql_get1))
                                         {
                                           /* echo '<li role="presentation" class="active"  text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].'"> '.$result['message'].'  </a></li>'; -->  */
                                            echo '<a class="dropdown-item" text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].' ">'.$result['message']. '</a></li>';
                                           echo '<div class ="dropdown-divider"></div>';
                                        }
                                    }else
                                    {
                                        echo '<a class="dropdown-item" text="primary" class="active" text="danger" font="bold">Sorry no new messages </a></li>';
                                    }


                            ?>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            
                            <li role="presentation" class="active"><a href="LOGINPAGE.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Notifications </h1>
    <hr>
    <div class="container">
        <div>
            <ul class="nav nav-tabs">
                <li><a href="#tab-1" role="tab" data-toggle="tab">Inbox </a></li>
                <li class="active"><a href="#tab-2" role="tab" data-toggle="tab">Create Broadcast</a></li>
                <li><a href="#tab-3" role="tab" data-toggle="tab">Compose Message</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane" role="tabpanel" id="tab-1">
                    <!--tab1 starts here--->
             <div class="container">
                          <hr>
                    <div class="panel-group" role="tablist" aria-multiselectable="true" id="accordion-1">
                      <div class="panel panel-default">
                      <div class="panel-body">               
                       <table class ="table">
                            <thead  class= "thread-dark">
                                <tr>
                                    <th scope="col">id</th>
                                    <th scope="col">Tittle</th>
                                    <th scope="col">Message</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Delete</th>
                              </tr>
                            </thead>               
                            <tbody>
                                <?php
                                    $sr_num=1;
                                $sql_get = mysqli_query($conn, "SELECT * FROM notification WHERE status = 1");
                                    while($main_result = mysqli_fetch_assoc($sql_get)):
                                ?>
                                <tr>
                                    <th scope="row"><?php echo $sr_num++; ?></th>
                                    <td ><?php echo $main_result['name']; ?></td>
                                    <td ><?php echo $main_result['message']; ?></td>
                                    <td ><?php echo $main_result['date']; ?></td>

                                    <td ><a href="Delete.php?id=<?php echo $main_result['id'];?>" class= "text-danger" ><i class="far fa-trash"></i></i></a></td>
                                </tr>

                            <?php endwhile ?>
                        </tbody>
                        </table>
                         </div>
                    </div>
            </div>
              </div>
              <div class="container">
                         <hr>
                             <div class="panel-group" role="tablist" aria-multiselectable="true" id="accordion-1">
                                <div class="panel panel-default">
                                                <div class="panel-body">               
                                                    <table class ="table">
                                                       <thead  class= "thread-dark">
                                                            <tr>
                                                                <th scope="col">id</th>
                                                                <th scope="col">Tittle</th>
                                                                <th scope="col">Announcements</th>
                                                                <th scope="col">Date</th>
                                                                <th scope="col">Delete</th>
                                                            </tr>
                                                        </thead>               
                                                            <tbody>
                                                                <?php
                                                                    $sr_num=1;
                                                                $sql_get = mysqli_query($conn, "SELECT * FROM send_message WHERE status = 1");
                                                                    while($main_result = mysqli_fetch_assoc($sql_get)):
                                                                ?>
                                                                    <tr>
                                                                        <th scope="row"><?php echo $sr_num++; ?></th>
                                                                        <td ><?php echo $main_result['name']; ?></td>
                                                                        <td ><?php echo $main_result['message']; ?></td>
                                                                        <td ><?php echo $main_result['date']; ?></td>

                                                                        <td ><a href="Delete.php?id=<?php echo $main_result['id'];?>" class= "text-danger" ><i class="far fa-trash"></i></i></a></td>
                                                                    </tr>

                                                                            <?php endwhile ?>
                                                            </tbody>
                                                    </table>
                                                </div>
                                   </div>
                                         </div>
                        </div>
                    <!--tab1 ends here--->
                </div>
                <div class="tab-pane active" role="tabpanel" id="tab-2">
                  <!---tab2--->

                     <div class="container">
                       <hr>

         <form action="" method= "POST" class="bootstrap-form-with-validation">
        <div class="form-group">
             
            <!--button class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false" type="button" name="group">Select Group <span class="caret"></span></button-->
                <label for="">Group: </label>
                <select name="send_to" class="form-control">
                     <option value="">Select group</option>
                    <option value="All Student">All Students</option>
                    <option value="DCS 100">First Years</option>
                    <option value="DCS 200">Second years</option>
                    <option value="DCS 300">Third years</option>
                </select>
             <label class="control-label"for="textarea-input">Subject Line</label>
                <input class="form-control" type="text" name="name" id="textarea-input">
            </div>
            <div class="form-group"></div>
            <div class="form-group">
                <label class="control-label" for="textarea-input">Textarea </label>
                <textarea class="form-control" name="message" id="textarea-input"></textarea>
            </div>
            <div class="form-group"></div>
            <div class="form-group"></div>
            <div class="form-group"></div>
            <div class="form-group"></div>
            <div class="form-group">
                <button type="submit" name="Send" class="btn btn-primary">Send </button>
            </div>
        </form>
               



        </div>

        <!----tab2 ends here---->
    </div>
                <div class="tab-pane" role="tabpanel" id="tab-3">
                      <!-----tab3----->

                               <div class="container">
                                <hr>

         <form action="" method= "POST" class="bootstrap-form-with-validation">
        <div class="form-group">
                <label for="">Send To</label>
                <input class="form-control" type="text" name="send_to" id="textarea-input">
             <label class="control-label"for="textarea-input">Subject Line</label>
                <input class="form-control" type="text" name="subject" id="textarea-input">
            </div>
            <div class="form-group"></div>
            <div class="form-group">
                <label class="control-label" for="textarea-input">Textarea </label>
                <textarea class="form-control" name="message" id="textarea-input"></textarea>
            </div>
            <div class="form-group"></div>
            <div class="form-group"></div>
            <div class="form-group"></div>
            <div class="form-group"></div>
            <div class="form-group">
                <button type="submit" name="Sendto" class="btn btn-primary">Send </button>
            </div>
        </form>
        </div>
                <!---tab3 ends here--->
            </div>


        </div>
        <hr>
        <!--label for="password-input">To; </label-->
    </div>
   
    
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>