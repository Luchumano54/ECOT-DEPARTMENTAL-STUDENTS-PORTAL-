<?php 

$conn = mysqli_connect('localhost','root','','Student portal');

if($conn)
{
	echo "";
}else
{
	echo mysqli_error($conn);
}











?>