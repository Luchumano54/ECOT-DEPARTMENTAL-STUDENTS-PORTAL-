
<?php 
   include "connection.php";

        session_start();
    if (empty($_SESSION['user_id'])){
        header("location: LOGINPAGE.php");
        exit();
    }

 ?>





<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body>
    <img class="img-responsive" src="assets/img/FINALv2.jpg" style="width: 100%;">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#"><?php echo $_SESSION['user_id']; ?></a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
             <?php  
         
                    $sql_get = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                    $count = mysqli_num_rows($sql_get);

            ?>


            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a class="text-muted bg-warning" href="find_student.php">Find A Student</a></li>
                    <li role="presentation"><a href="assess_lecturer.php">Assessments </a></li>
                    <li role="presentation"><a href="cal_lect.php">Add Event </a></li>
                    <li role="presentation"><a href="#"> Reports</a></li>
                    <li role="presentation"><a href="NOT CB LECT.php" class="custom-navbar">  Notification <span class="badge" ><?php echo $count; ?> </span></a></li>
                    <li><li class="dropdown open">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" href="#"> <span class="caret"></span></a>
                        <ul class="dropdown-menu dropdown-menu" role="menu">
                            <?php
                                    $sql_get1 = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                                    if(mysqli_num_rows($sql_get1)) 
                                    {
                                        while ($result =mysqli_fetch_assoc($sql_get1))
                                         {
                                           /* echo '<li role="presentation" class="active"  text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].'"> '.$result['message'].'  </a></li>'; -->  */
                                            echo '<a class="dropdown-item" text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].' ">'.$result['message']. '</a></li>';
                                           echo '<div class ="dropdown-divider"></div>';
                                        }
                                    }else
                                    {
                                        echo '<a class="dropdown-item" text="primary" class="active" text="danger" font="bold">Sorry no new messages </a></li>';
                                    }


                            ?>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                             
                            <li role="presentation" class="active"><a href="LOGINPAGE.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Reports </h1>
    <hr>
    <div class="container">
        <div>
            <ul class="nav nav-tabs">
                
               <!--  -->
                <li class="active"><a href="res.php" role="presentation" >Continuous Assesment</a></li>
                <li><a href="examTab.php" role="presentation" >Exam Mark</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" role="tabpanel" id="tab-1"></div>
                <div class="tab-pane" role="tabpanel" id="tab-2" href="examTab.php">
                    <p>Second tab content.</p>
                </div>
               
            </div>
        </div>
    </div>
    <div class="container">
        <hr>
    </div>
   
            
            </div>
        </div>
    </div>
    <div class="container">
        <hr>
    </div>
           

    <div class="container">
        <form action="insertAssignment.php" method="post">
            <fieldset>
        <legend style="color: blue;"><h2 class="text-center"><i class="glyphicon glyphicon-plus"></i> Record Assignment </h2></legend>  
            

                <?php

                    $select_class_query="SELECT `course_code` from `course`";
                    $class_result=mysqli_query($conn,$select_class_query);
                    //select class
                    echo '<select name="class_name" >';
                    echo '<option selected disabled >Select Class</option>';
                    
                        while($row = mysqli_fetch_array($class_result)) {
                            $display=$row['course_code'];
                            echo '<option  value="'.$display.'">'.$display.'</option>';
                        }
                    echo'</select>';                      
                ?>

                 <?php


                    $select_class_query1="SELECT `StudentNumber` from `studentp`";
                    $class_result1=mysqli_query($conn,$select_class_query1);
                    echo '<select name="Std_Num" >';
                    echo '<option selected disabled >Select Student ID</option>';
                    
                        while($row1 = mysqli_fetch_array($class_result1)) {
                            $display1=$row1['StudentNumber'];
                            echo '<option  value="'.$display1.'">'.$display1.'</option>';
                        }
                    echo'</select>';                      
                ?>

               <!-- <input type="text" name="rno" placeholder="Roll No"> -->
                <input type="text" name="assign1" id="" placeholder="Assignment 1">
                <input type="text" name="assign2" id="" placeholder="Assignment 2">
                <input type="text" name="assign3" id="" placeholder="Assignment 3">
                <input type="text" name="assign4" id="" placeholder="Assignment 4">
                <input type="submit" value="Submit">
            </fieldset>
        </form>
    </div>



  
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
   
                

                               <div class="container">
        <form action="insertQuize.php" method="post">
            <fieldset>
        <legend style="color: blue;"><h2 class="text-center"><i class="glyphicon glyphicon-plus"></i> Record Quiz </h2></legend>  
            

                <?php
                    //include("init.php");
                   // include("session.php");

                    $select_class_query="SELECT `course_code` from `course`";
                    $class_result=mysqli_query($conn,$select_class_query);
                    //select class
                    echo '<select name="class_name" >';
                    echo '<option selected disabled >Select Class</option>';
                    
                        while($row = mysqli_fetch_array($class_result)) {
                            $display=$row['course_code'];
                            echo '<option  value="'.$display.'">'.$display.'</option>';
                        }
                    echo'</select>';                      
                ?>

                 <?php
                    //include("init.php");
                   // include("session.php");

                    $select_class_query1="SELECT `StudentNumber` from `studentp`";
                    $class_result1=mysqli_query($conn,$select_class_query1);
                    //select Student ID
                    echo '<select name="Std_Num" >';
                    echo '<option selected disabled >Select Student ID</option>';
                    
                        while($row1 = mysqli_fetch_array($class_result1)) {
                            $display1=$row1['StudentNumber'];
                            echo '<option  value="'.$display1.'">'.$display1.'</option>';
                        }
                    echo'</select>';                      
                ?>

               <!-- <input type="text" name="rno" placeholder="Roll No"> -->
                <input type="text" name="quize1" id="" placeholder="Quiz 1">
                <input type="text" name="quize2" id="" placeholder="Quiz 2">
                <input type="text" name="quize3" id="" placeholder="Quiz 3">
                <input type="text" name="quize4" id="" placeholder="Quiz 4">
                <input type="submit" value="Submit">
            </fieldset>
        </form>
    </div>



          
        </form>
        <hr>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>             
    <div class="container">
        <form action="insertTest.php" method="post">
            <fieldset>
        <legend style="color: blue;"><h2 class="text-center"><i class="glyphicon glyphicon-plus"></i> Record Test </h2></legend>  
            

                <?php
                    //include("init.php");
                   // include("session.php");

                    $select_class_query="SELECT `course_code` from `course`";
                    $class_result=mysqli_query($conn,$select_class_query);
                    //select class
                    echo '<select name="class_name" >';
                    echo '<option selected disabled >Select Class</option>';
                    
                        while($row = mysqli_fetch_array($class_result)) {
                            $display=$row['course_code'];
                            echo '<option  value="'.$display.'">'.$display.'</option>';
                        }
                    echo'</select>';                      
                ?>

                 <?php
                    //include("init.php");
                   // include("session.php");

                    $select_class_query1="SELECT `StudentNumber` from `studentp`";
                    $class_result1=mysqli_query($conn,$select_class_query1);
                    //select Student ID
                    echo '<select name="Std_Num" >';
                    echo '<option selected disabled >Select Student ID</option>';
                    
                        while($row1 = mysqli_fetch_array($class_result1)) {
                            $display1=$row1['StudentNumber'];
                            echo '<option  value="'.$display1.'">'.$display1.'</option>';
                        }
                    echo'</select>';                      
                ?>

               <!-- <input type="text" name="rno" placeholder="Roll No"> -->
                <input type="text" name="test1" id="" placeholder="Test 1">
                <input type="text" name="test2" id="" placeholder="Test 2">
                <input type="text" name="test3" id="" placeholder="Test 3">
                <input type="text" name="test4" id="" placeholder="Test 4">
                <input type="submit" value="Submit">
            </fieldset>
        </form>
    </div>
        <hr>
    </div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>


