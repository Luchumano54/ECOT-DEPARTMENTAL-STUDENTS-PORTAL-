<?php

/*$conn = mysql_connect("localhost","root","","management");
 $sql = "SELECT * FROM filez";
 $result = mysqli_query$conn,$sql);
$filez = mysqli_fetch_all($result,MYSQLI_ASS0C);
*/
$conn = new mysqli("localhost", "root","","student portal");
  $msg = "";
 $sql = "SELECT * FROM assessment";
  $result = mysqli_query($conn,$sql);
  $filez = mysqli_fetch_all($result,MYSQLI_ASSOC);

  //var_dump($filez);

if(isset($_FILES)){
	//var_dump($_FILES);
	$filename = $_FILES['myfile']['name'];
	$destination = 'uploads/'. $filename;
	$extension = pathinfo($filename,PATHINFO_EXTENSION);
	$file = $_FILES['myfile']['tmp_name'];
	$size = $_FILES['myfile']['size'];
	$datee= $_POST['assessment_date'];
	$course_code= $_POST['course_code'];

	if(!in_array($extension, ['zip','pdf','png','txt'])){
		echo "your file extension must be .zip, .pdf or .png";
	}else if ($_FILES["myfile"]["size"]> 1000000000) {
		echo "file is too large";
	}
	else{
		if (move_uploaded_file($file, $destination)){
			//INSERT INTO `student portal`.`assessment` (`ass_id`, `ass_title`, `ass_size`, `ass_downloads`, `ass_date`) VALUES (NULL, 'dfhjg', '4', '6', '2021-06-02');
			$sql = "INSERT INTO assessment (assessment_title,assessment_size,assessment_downloads,assessment_date,course_code) VALUES('$filename','$size',0,'$datee','$course_code')";
               

			
			if(mysqli_query($conn,$sql)){
				echo "file uploaded";
			}else{
				echo "failed to upload****";
			}
		}

	}
}

?>