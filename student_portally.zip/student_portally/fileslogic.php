<?php

/*$conn = mysql_connect("localhost","root","","management");
 $sql = "SELECT * FROM filez";
 $result = mysqli_query$conn,$sql);
$filez = mysqli_fetch_all($result,MYSQLI_ASS0C);
*/
$conn = new mysqli("localhost", "root","","student portal");
  $msg = "";
 $sql = "SELECT * FROM test";
  $result = mysqli_query($conn,$sql);
  $filez = mysqli_fetch_all($result,MYSQLI_ASSOC);

  //var_dump($filez);

if(isset($_FILES)){
	//var_dump($_FILES);
	$filename = $_FILES['myfile']['name'];
	$destination = 'upload/'. $filename;
	$extension = pathinfo($filename,PATHINFO_EXTENSION);
	$file = $_FILES['myfile']['tmp_name'];
	$size = $_FILES['myfile']['size'];
	if(!in_array($extension, ['zip','pdf','png','txt'])){
		echo "your file extension must be .zip, .pdf or .png";
	}else if ($_FILES["myfile"]["size"]> 1000000000) {
		echo "file is too large";
	}
	else{
		if (move_uploaded_file($file, $destination)){
			$sql = "INSERT INTO test(test_name,size,downloadd) VALUES('$filename','$size',0)";
			if(mysqli_query($conn,$sql)){
				echo "file uploaded";
			}else{
				echo "failed to upload";
			}
		}

	}
}

?>