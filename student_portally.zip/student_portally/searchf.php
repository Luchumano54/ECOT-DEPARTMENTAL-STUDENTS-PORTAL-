<?php
error_reporting(0);
$conn = mysqli_connect("localhost","root","","student portal");
if(count($_POST)>0) {
$StudentNumber=$_POST[StudentNumber];
$result = mysqli_query($conn,"SELECT * FROM studentp where StudentNumber='$StudentNumber' ");

 session_start();
    if (empty($_SESSION['user_id'])){
        header("location: LOGINPAGE.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title> Retrive data</title>


 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
    <link href="calendar.css" rel="stylesheet" type="text/css">
</head>
<body>
<img class="img-responsive" src="assets/img/FINALv2.jpg">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#"><?php echo $_SESSION['user_id']; ?> </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a class="text-muted bg-warning" href="FAS HOF.php">Find A Student</a></li>
                      <li role="presentation"><a href="add_student_final.php"> Add A Student</a></li>
                     <li role="presentation"><a href="Reports HOF.php"> Reports</a></li>
                     <li role="presentation"><a href="addevent.php">Add Event</a></li>
                    <li role="presentation"><a href="NOT IB HOF.php" class="custom-navbar"> Notification <span class="badge" ><?php echo $count; ?> </span></a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            <!--li role="presentation"><a href="#">Settings </a></li>
                            <li role="presentation"><a href="#">Payments </a></li-->
                            <li role="presentation" class="active"><a href="LOGINPAGE.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <h1 class="text-center">Student Profile</h1>
    <hr>
        <div class="container">
                          <hr>
                    <div class="panel-group" role="tablist" aria-multiselectable="true" id="accordion-1">
                      <div class="panel panel-default">
                      <div class="panel-body">
    <table class ="table">
         
        <tr>
            <th>Student Number</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Phone Number</th>
            <th>Gender</th>
            <th>Date of birth</th>
            <th>Year</th>
        </tr>        
        <?php
        $i=0;
        while($row = mysqli_fetch_array($result)) {
        ?>
        <tr>
        <td><?php echo $row["StudentNumber"]; ?></td>    
        <td><?php echo $row["FirstName"]; ?></td>
        <td><?php echo $row["LastName"]; ?></td>
         <td><?php echo $row["PhoneNum"]; ?></td>
        <td><?php echo $row["Gender"]; ?></td>
         <td><?php echo $row["datee"]; ?></td>
          <td><?php echo $row["course"]; ?></td>
        </tr>
    <?php
    $i++;
    }
    ?>
    </table>
</div>
</div>
</div>
</div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>