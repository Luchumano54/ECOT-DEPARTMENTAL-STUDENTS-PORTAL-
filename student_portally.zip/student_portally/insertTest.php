


<?php

    include 'connection.php';

    if(isset($_POST['class_name'],$_POST['Std_Num']))
    {

        $class_name=$_POST['class_name'];
        $Std_Num=$_POST['Std_Num'];
        $test1=(int)$_POST['test1'];
        $test2=(int)$_POST['test2'];
        $test3=(int)$_POST['test3'];
        $test4=(int)$_POST['test4'];
        $aveTest = (int)($test1+$test2+$test3+$test4)/4;


        $sql="INSERT INTO `test_table` (`student_id`, `course_code`, `tes1`, `tes2`, `tes3`, `tes4`,aveTest) VALUES ('$Std_Num', '$class_name','$test1', '$test2', '$test3', '$test4','$aveTest')";
        $sql=mysqli_query($conn,$sql);

        if (!$sql) {
            echo $aveTest;
            echo '<script language="javascript">';
            echo 'alert("Invalid Details")';
            echo '</script>';
            //call last added data


            
        }
        else{
            header ('Location: res.php');
            echo '<script language="javascript">';
            echo "New record created successfully";
            echo '</script>';
        }
    }else{
        echo "Select class name or student number!!";
    }
?>