<html><head>
<?php
include("connection.php");
include('functionality.php');
$object = new alpha();

?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">

		<title>Student Report</title>
		
		<style>
				.container {
					width:75%;
					margin:auto;
				}
						
				.table {
				    width: 100%;
				    margin-bottom: 20px;
				}	

				.table-striped tbody > tr:nth-child(odd) > td,
				.table-striped tbody > tr:nth-child(odd) > th {
				    background-color: #f9f9f9;
				}

				@media print{
				#print {
					display:none;
				}
				}

				#print {
					width: 90px;
				    height: 30px;
				    font-size: 18px;
				    border-radius: 4px;
					margin-left:28px;
					cursor:hand;
				}
		
		</style>
		<script>
			function printPage() {
			    window.print();
			}
		</script>
		
</head>
<body>

	<div class = "container">
                <div class="card ">
                    <div class="card-body" style="padding: 1%;">
                        <h2 class="text-center" style="font-weight: bold;">ESWATINI COLLEGE OF TECHNOLOGY</h2>
                        <div>
                            <center><img class="img-fluid" src="assets/img/ECZOT.jpg" style="height: 150px; width: 150px;"></center>
                        </div>

                        <div class="text-center">
                           <h5>FUCULTY OF INFORMATION COMMUNICATION AND TECHNOLOGY</h5>
                        </div>
                        <br/>
                        <br/>
                        <div>
                            <h5 style="float: right;"><b>Date:&nbsp;<?php include('current-date.php'); ?></b></h5>
                           <h5><b>Student ID:&nbsp;<?php echo $_SESSION['user_id']; ?></b></h5>
                        </div>
                        <div >
                            <?php
                                include("connection.php");
                                $sql = "SELECT * FROM ca_table where student_id = ".$_SESSION['user_id'];

                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                  // output data of each row
                                echo "<table class='table table-striped'>
                                <thead>
                                <tr>
                                    <td align='center'>Course Code</td>
                                    <td align='center'> CA Mark</td>
                                    <td align='center'>Exam Mark</td>
                                    <td align='center'>Final Mark</td>
                                    <td align='center'>Status</td>
                                </tr>
                                </thead>
                                <tbody>";
                                while($row = $result->fetch_assoc()) {
                                	$fca =(($row["avAsignment"]+$row["avQuiz"]+$row["avTest"])/3);
                                	$fmark = ($row["exam_mark"] + $fca)/2;
                                	$status = null;

                                	if ($fmark<=100 and $fmark>=50 ) {

                                		$status = 'Pass';
                                	}else if ($fmark <=50 and $fmark>=0) {
                                		$status = 'Fail';
                                	}

                                    echo "<tr><td align='center'>" . $row["course_code"]. "</td><td align='center'> ". ceil($fca) . "</td><td align='center'> ".ceil($row['exam_mark']) ."</td><td align='center'> ". ceil($fmark) . "</td><td align='center'> " .$status. "</td></tr>";
                                    
                                    }
                                   echo " </tbody>
                                    </table>";
                                    } else {
                                  echo "0 results";
                                }
                            ?>
                        </div>
                    </div>
				</div>
			<br/>
			<button type="submit" id="print" onclick="printPage()">Print</button>
	</div>
</body>


</html>

