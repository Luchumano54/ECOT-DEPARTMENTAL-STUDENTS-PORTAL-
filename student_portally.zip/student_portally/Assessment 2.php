<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">Mr Dlamini</a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a class="text-muted bg-warning" href="Find A Student lecturer.php">Find A Student</a></li>
                    <!---<li role="presentation"><a href="#">Assessments </a></li> -->
                    <li role="presentation"><a href="LECT Report.php"> Reports</a></li>
                    <li role="presentation"><a href="#" class="custom-navbar"> Inbox<span class="badge">10 </span></a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            <li role="presentation"><a href="#">Settings </a></li>
                            <li role="presentation"><a href="#">Payments </a></li>
                            <li role="presentation" class="active"><a href="#">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Assesments </h1>
    <hr>
    <div class="container">
        <div>
            <ul class="nav nav-tabs">
                <li><a href="#tab-1" role="tab" data-toggle="tab">Upload Work</a></li>
                <li class="active"><a href="#tab-2" role="tab" data-toggle="tab">Download Work </a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane" role="tabpanel" id="tab-1">
                    <p>Remember to set due Date and Time.</p>
                </div>
                <div class="tab-pane active" role="tabpanel" id="tab-2"></div>
                <div class="tab-pane" role="tabpanel" id="tab-3">
                    <p>Third tab content.</p>
                </div>
            </div>
        </div>
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">Due Work</a>
                    <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                </div>
                <div class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav">
                        <li class="active" role="presentation"><a href="#">Quiz </a></li>
                        <li role="presentation"><a href="#">Assignment </a></li>
                        <li role="presentation"><a href="#">Test </a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <hr>
    </div>
    <div class="container">
        <div class="panel-group" role="tablist" aria-multiselectable="true" id="accordion-1">
            <div class="panel panel-default">
                <div class="panel-heading" role="tab">
                    <h4 class="panel-title"><a role="button" data-toggle="collapse" data-parent="#accordion-1" aria-expanded="true" href="#accordion-1 .item-1">180239001 Turned in Late</a></h4></div>
                <div class="panel-collapse collapse in item-1" role="tabpanel"></div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading" role="tab">
                    <h4 class="panel-title"><a role="button" data-toggle="collapse" data-parent="#accordion-1" aria-expanded="false" href="#accordion-1 .item-2">180239002 Missing</a></h4></div>
                <div class="panel-collapse collapse item-2" role="tabpanel">
                    <div class="panel-body"><span>Item body.</span></div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading" role="tab">
                    <h4 class="panel-title"><a role="button" data-toggle="collapse" data-parent="#accordion-1" aria-expanded="false" href="#accordion-1 .item-3">180239003 Turned in on Time</a></h4></div>
                <div class="panel-collapse collapse item-3" role="tabpanel">
                    <div class="panel-body"><span>Item body.</span></div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading" role="tab">
                    <h4 class="panel-title"><a role="button" data-toggle="collapse" data-parent="#accordion-1" aria-expanded="false" href="#accordion-1 .item-4">180239004 Turned in on Time</a></h4></div>
                <div class="panel-collapse collapse item-4" role="tabpanel">
                    <div class="panel-body"><span>Item body.</span></div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading" role="tab">
                    <h4 class="panel-title"><a role="button" data-toggle="collapse" data-parent="#accordion-1" aria-expanded="false" href="#accordion-1 .item-5">180239005 Turned in Late</a></h4></div>
                <div class="panel-collapse collapse item-5" role="tabpanel">
                    <div class="panel-body"><span>Item body.</span></div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading" role="tab">
                    <h4 class="panel-title"><a role="button" data-toggle="collapse" data-parent="#accordion-1" aria-expanded="false" href="#accordion-1 .item-6">180239006 Turned in on Time</a></h4></div>
                <div class="panel-collapse collapse item-6" role="tabpanel">
                    <div class="panel-body"><span>Item body.</span></div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <button class="btn btn-default" type="button">Download Work</button>
        <hr>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>