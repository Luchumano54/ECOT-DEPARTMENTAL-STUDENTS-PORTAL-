      

<!DOCTYPE html>
<html>

<head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>.ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg">
    <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">180239003 </a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a class="text-muted bg-warning" href="#">Student Profile</a></li>
                    <li role="presentation"><a href="#">Assessments </a></li>
                    <li role="presentation"><a href="#"> Reports</a></li>
                    <li role="presentation"><a href="#" class="custom-navbar"> Notifications<span class="badge">10 </span></a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            <li role="presentation"><a href="#">Settings </a></li>
                            <li role="presentation"><a href="#">Payments </a></li>
                            <li role="presentation" class="active"><a href="#">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Assessments </h1>
    <hr>
    <div class="container">
        <div class="dropdown">
            <button class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false" type="button">Select Course <span class="caret"></span></button>
            <ul class="dropdown-menu" role="menu">
                <li role="presentation"><a href="#">First Item</a></li>
                <li role="presentation"><a href="#">Second Item</a></li>
                <li role="presentation"><a href="#">Third Item</a></li>
            </ul>
        </div>
        <hr>
    </div>
    <div class="container">
        <div>
            <ul class="nav nav-tabs">
                <li><a href="#tab-1" role="tab" data-toggle="tab">Test </a></li>
                <li><a href="#tab-2" role="tab" data-toggle="tab">Quiz </a></li>
                <li class="active"><a href="#tab-3" role="tab" data-toggle="tab">Assignment </a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane" role="tabpanel" id="tab-1">
                    <p>First tab content.</p>
                </div>
                <div class="tab-pane" role="tabpanel" id="tab-2">
                    <p>Second tab content.</p>
                </div>
                <div class="tab-pane active" role="tabpanel" id="tab-3"></div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="input-group">
            <div class="input-group-addon"><span>Due Time :<strong>12:30</strong></span></div>
            <input class="form-control" type="text">
            <div class="input-group-btn">
                            <?php/*
            $query=$conn->query("select * from upload order by id desc");
            while($row=$query->fetch()){
                $name=$row['name'];
            */?>
            <tr>
                <td>
                    &nbsp;<?php echo $name ;?>
                </td>
                <td>
                    <button class="btn btn-default"><a href="download.php?filename=<?php echo $name;?>&f=<?php echo $row['fname'] ?>"type="button">Download Assignment  </a> </button>
                 
                </button>
                </td>
            </tr>
            <?php// }?>
            </div>
        </div>
        <div class="input-group">
            <div class="input-group-addon"><span>Upload Your Assignment Here!</span></div>
            <input class="form-control" type="text">

            <div class="input-group-btn">
                        <form enctype="multipart/form-data" action="fileslogicStudent.php" name="form" method="post">
            Select File
                <input type="file" name="myfile" id="myfile" />
                <!--input type="submit" name="submit" id="submit" value="Submit" /-->

        
            
            </div>
        </div>
    </div>
    <hr>
    <div class="container">
        <button class="btn btn-default" type="submit">Submit your Work</button>
        </form>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>