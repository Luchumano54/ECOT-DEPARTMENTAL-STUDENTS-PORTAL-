<?php 
   include "connection.php";?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ECOT STUDENT PORTAL</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Material-Card.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
    <link rel="stylesheet" href="assets/css/Pretty-Footer.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/Pretty-Header.css">
    <link rel="stylesheet" href="assets/css/Mockup-iPhone-6.css">
</head>

<body><img class="img-responsive" src="assets/img/FINALv2.jpg" style="width: 100%;">
   <nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
             <?php

                session_start();
                 if (empty($_SESSION['user_id'])){
                    header("location: LOGINPAGE.php");
                    exit();
    }
            ?>
            <div class="navbar-header"><a class="navbar-brand navbar-link" href="#"><?php echo $_SESSION['user_id']; ?></a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>

            <?php  
         
                    $sql_get = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                    $count = mysqli_num_rows($sql_get);

            ?>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a class="text-muted bg-warning" href="FAS HOF.php">Find A Student</a></li>
                      <li role="presentation"><a href="add_student_final.php"> Add A Student</a></li>
                     <li role="presentation"><a href="Reports HOF.php"> Reports</a></li>
                     <li role="presentation"><a href="addevent.php">Add Event</a></li>
                    <li role="presentation"><a href="NOT IB HOF.php" class="custom-navbar"> Notification <span class="badge" ><?php echo $count; ?> </span></a></li>
                    <li><li class="dropdown open">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" href="#"> <span class="caret"></span></a>
                        <ul class="dropdown-menu dropdown-menu" role="menu">
                            <?php
                                    $sql_get1 = mysqli_query($conn, "SELECT * FROM notification WHERE status = 0");   
                                    if(mysqli_num_rows($sql_get1)) 
                                    {
                                        while ($result =mysqli_fetch_assoc($sql_get1))
                                         {
                                           /* echo '<li role="presentation" class="active"  text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].'"> '.$result['message'].'  </a></li>'; -->  */
                                            echo '<a class="dropdown-item" text="primary" font="bold" href="NOT CM STU final.php?id='. $result['id'].' ">'.$result['message']. '</a></li>';
                                           echo '<div class ="dropdown-divider"></div>';
                                        }
                                    }else
                                    {
                                        echo '<a class="dropdown-item" text="primary" class="active" text="danger" font="bold">Sorry no new messages </a></li>';
                                    }


                            ?>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar_2x.png" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            
                            <li role="presentation" class="active"><a href="LOGINPAGE.php">Logout </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <hr>
    <h1 class="text-center">Find A Student </h1>
    <br>
    <!--div class="container">
        <div>
            <ul class="nav nav-tabs">
                <li class="active"><a href="#tab-1" role="tab" data-toggle="tab">Continuous Assesment</a></li>
                <li><a href="#tab-2" role="tab" data-toggle="tab">Exam Mark</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" role="tabpanel" id="tab-1"></div>
                <div class="tab-pane" role="tabpanel" id="tab-2">
                    <p>Second tab content.</p>
                </div>
                <div class="tab-pane" role="tabpanel" id="tab-3">
                    <p>Third tab content.</p>
                </div>
            </div>
        </div>
    </div-->
       <!--div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="btn-group open">
                    <button class="btn btn-default" type="button">Select Course</button>
                    <button class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="true" type="button"><span class="caret"></span></button>
                    <ul class="dropdown-menu" role="menu">
                        <li role="presentation"><a class="bg-info" href="#">Programming </a></li>
                        <li role="presentation"><a href="#">Software Engineering</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6">
                <div class="checkbox">
                    <label>
                        <input type="checkbox">Quiz</label>
                </div>
                <div class="checkbox">
                    <label>
                        <input type="checkbox" checked="">Test</label>
                </div>
                <div class="checkbox">
                    <label>
                        <input type="checkbox">Assignment</label>
                </div>
            </div>
        </div>
    </div-->
       <div class="container">
        <form class="bootstrap-form-with-validation"  method="post" action="searchf.php">
            <div class="form-group">
                <label class="control-label" for="search-input">Search Student</label>
                <div class="input-group">
                    <div class="input-group-addon"><span> <i class="glyphicon glyphicon-search"></i></span></div>
                    <input class="form-control" type="search" name="StudentNumber" placeholder="  enter StudentNumber " id="submit">
                </div>
            </div>
            <div class="form-group">
                <button class="btn btn-primary" type="submit">Search </button>
            </div>
        </form>
    </div>
    <!--div class="container">
        <form class="form-inline bootstrap-form-with-validation">
            <div class="form-group">
                <label class="control-label sr-only" for="email-input">Email </label>
                <input class="form-control" type="email" placeholder="Input Mark" id="email-input">
            </div>
            <div class="form-group">
                <label class="control-label sr-only" for="password-input">Password </label>
            </div>
            <div class="checkbox">
                <label> </label>
            </div>
            <button class="btn btn-default" type="submit">Done </button>
        </form>
        <hr>
    </div-->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>