<?php


$conn = new mysqli("localhost", "root","","student portal");

if (isset($_POST['submit'])) {
	$StudentNumber = $_POST['StudentNumber'];
	$FirstName = $_POST['FirstName'];
	$LastName = $_POST['LastName'];
	$PhoneNum =$_POST['PhoneNum'];
	$passwordd =$_POST['passwordd'];
	$Gender = $_POST['Gender'];
  $datee = $_POST['datee'];
  $course =$_POST['course'];
	

$sql = "INSERT INTO studentp (StudentNumber,FirstName,LastName,PhoneNum,passwordd,Gender,datee,course) VALUES ('$StudentNumber','$FirstName','$LastName','$PhoneNum',$passwordd,'$Gender','$datee','$course')";
 //$sql="INSERT INTO `student portal`.`student` (`StudentNumber`, `FirstName`, `LastName`, `PhoneNum`, `passwordd`, `Gender`, `datee`, `course`) VALUES ('181239042', 'FELICIA', 'Mabhena', '76742211', '6790', 'female', '2021-06-01', 'DCS100')";
$result = mysqli_query($conn,"SELECT * FROM studentp");



if ($conn->query($sql) === TRUE) {
   echo "<script>alert('message sent successful;')</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
}
$conn->close();
?>